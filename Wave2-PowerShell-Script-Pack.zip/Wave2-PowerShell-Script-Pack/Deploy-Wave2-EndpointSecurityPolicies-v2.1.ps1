<#
.SYNOPSIS
    Deploys Wave 2 Endpoint Security Intune policies using Microsoft Graph.

.DESCRIPTION
    Creates or reuses Windows 10/11 custom configuration policies for:
      - Microsoft Defender Antivirus baseline
      - Attack Surface Reduction rules in Audit mode (optional custom OMA-URI mode)

    This script deliberately uses Windows Custom Configuration / OMA-URI policies
    because these CSP-backed settings are stable and easy to validate.

    Scope covered in this v1:
      - Endpoint protection using Microsoft Defender for Endpoint / Defender Antivirus
      - Attack Surface Reduction rules in Audit mode (optional custom OMA-URI mode)

    Scope now deployed in this v2:
      - Windows Firewall
      - Safe core BitLocker

    Scope intentionally scaffolded but NOT deployed in this v2:
      - macOS Defender
      - macOS FileVault
      - macOS Firewall

    Those remaining profiles should be deployed using Settings Catalog / Endpoint Security profiles or exported
    validated JSON from a pilot tenant, because the settingDefinitionIds and template behaviour
    can vary and are more brittle through Graph.

.REQUIREMENTS
    PowerShell 7 recommended.
    Microsoft.Graph.Authentication module.

.GRAPH PERMISSIONS
    DeviceManagementConfiguration.ReadWrite.All
    Directory.Read.All

.EXAMPLE
    .\Deploy-Wave2-EndpointSecurityPolicies-v2.ps1 `
        -TenantId "00000000-0000-0000-0000-000000000000" `
        -PilotGroupId "533187c7-4628-47c3-bbc7-0d204def0f57"

.EXAMPLE
    Preview payloads without making changes:

    .\Deploy-Wave2-EndpointSecurityPolicies-v2.ps1 `
        -TenantId "00000000-0000-0000-0000-000000000000" `
        -PilotGroupId "533187c7-4628-47c3-bbc7-0d204def0f57" `
        -WhatIfOnly `
        -ShowJson

.NOTES
    ASR rule action values:
      0 = Disabled
      1 = Block
      2 = Audit
      6 = Warn

    This script skips ASR custom OMA-URI deployment by default. Use -IncludeASRCustomPolicy only for lab/testing or where explicitly required. Target production model: Defender-native ASR policy for SOC visibility.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$TenantId,

    [Parameter(Mandatory = $true)]
    [Alias("PilotGroupId")]
    [ValidatePattern('^[0-9a-fA-F-]{36}$')]
    [string]$TargetGroupId,

    [Parameter(Mandatory = $false)]
    [string]$PolicyNamePrefix = "W2-SEC",

    [Parameter(Mandatory = $false)]
    [ValidateSet("Audit", "Block", "Warn", "Disabled")]
    [string]$AsrMode = "Audit",

    [Parameter(Mandatory = $false)]
    [switch]$IncludeASRCustomPolicy,

    [Parameter(Mandatory = $false)]
    [switch]$UpdateExisting,

    [Parameter(Mandatory = $false)]
    [switch]$NoAssignments,

    [Parameter(Mandatory = $false)]
    [switch]$WhatIfOnly,

    [Parameter(Mandatory = $false)]
    [switch]$ShowJson
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$GraphBaseUri = "https://graph.microsoft.com/v1.0"

# -----------------------------
# Logging
# -----------------------------

function Write-Section {
    param([Parameter(Mandatory)][string]$Message)

    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host $Message -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
}

function Write-Info {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "[INFO] $Message" -ForegroundColor White
}

function Write-Success {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "[OK]   $Message" -ForegroundColor Green
}

function Write-Warn {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "[WARN] $Message" -ForegroundColor Yellow
}

function Write-Fail {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "[FAIL] $Message" -ForegroundColor Red
}

# -----------------------------
# Graph helpers
# -----------------------------

function Ensure-GraphAuthenticationModule {
    if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Authentication)) {
        Write-Warn "Microsoft.Graph.Authentication module is not installed."
        Write-Info "Installing Microsoft.Graph.Authentication for current user..."
        Install-Module Microsoft.Graph.Authentication -Scope CurrentUser -Force -AllowClobber
    }

    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
}

function Connect-ToGraph {
    Ensure-GraphAuthenticationModule

    $Scopes = @(
        "DeviceManagementConfiguration.ReadWrite.All",
        "Directory.Read.All"
    )

    $ExistingContext = Get-MgContext -ErrorAction SilentlyContinue

    if ($ExistingContext) {
        Write-Info "Existing Graph context detected for tenant $($ExistingContext.TenantId)."

        if ($TenantId -and ($ExistingContext.TenantId -ne $TenantId)) {
            Write-Warn "Connected tenant does not match requested tenant. Reconnecting..."
            Disconnect-MgGraph | Out-Null
            $ExistingContext = $null
        }
    }

    if (-not $ExistingContext) {
        if ($TenantId) {
            Write-Info "Connecting to Microsoft Graph tenant $TenantId..."
            Connect-MgGraph -TenantId $TenantId -Scopes $Scopes -NoWelcome | Out-Null
        }
        else {
            Write-Info "Connecting to Microsoft Graph..."
            Connect-MgGraph -Scopes $Scopes -NoWelcome | Out-Null
        }
    }

    $Context = Get-MgContext

    if (-not $Context) {
        throw "Could not establish Microsoft Graph context."
    }

    Write-Success "Connected to tenant $($Context.TenantId) as $($Context.Account)."
}

function ConvertTo-GraphJson {
    param([Parameter(Mandatory)]$Body)

    return ($Body | ConvertTo-Json -Depth 50)
}

function Get-GraphErrorText {
    param([Parameter(Mandatory)]$ErrorRecord)

    if ($ErrorRecord.ErrorDetails -and $ErrorRecord.ErrorDetails.Message) {
        return $ErrorRecord.ErrorDetails.Message
    }

    return $ErrorRecord.Exception.Message
}

function Invoke-GraphJson {
    param(
        [Parameter(Mandatory)]
        [ValidateSet("GET", "POST", "PATCH", "DELETE")]
        [string]$Method,

        [Parameter(Mandatory)]
        [string]$Uri,

        [Parameter(Mandatory = $false)]
        $Body
    )

    try {
        if ($PSBoundParameters.ContainsKey("Body") -and $null -ne $Body) {
            $Json = ConvertTo-GraphJson -Body $Body

            if ($ShowJson -or $WhatIfOnly) {
                Write-Host ""
                Write-Host "JSON PAYLOAD: $Method $Uri" -ForegroundColor DarkCyan
                Write-Host $Json
            }

            if ($WhatIfOnly) {
                return $null
            }

            return Invoke-MgGraphRequest `
                -Method $Method `
                -Uri $Uri `
                -Body $Json `
                -ContentType "application/json"
        }

        if ($WhatIfOnly) {
            Write-Host "WHATIF: $Method $Uri" -ForegroundColor Magenta
            return $null
        }

        return Invoke-MgGraphRequest -Method $Method -Uri $Uri
    }
    catch {
        Write-Fail "$Method $Uri failed."
        Write-Host (Get-GraphErrorText -ErrorRecord $_) -ForegroundColor Red
        throw
    }
}

function Escape-ODataString {
    param([Parameter(Mandatory)][string]$Value)
    return $Value.Replace("'", "''")
}

# -----------------------------
# Device configuration helpers
# -----------------------------

function Get-DeviceConfigurationByDisplayName {
    param([Parameter(Mandatory)][string]$DisplayName)

    $EscapedName = Escape-ODataString -Value $DisplayName
    $Uri = "$GraphBaseUri/deviceManagement/deviceConfigurations?`$filter=displayName eq '$EscapedName'"

    $Response = Invoke-GraphJson -Method GET -Uri $Uri

    if ($Response -and $Response.value -and $Response.value.Count -gt 0) {
        return $Response.value[0]
    }

    return $null
}

function New-OrUpdate-DeviceConfiguration {
    param(
        [Parameter(Mandatory)]
        [hashtable]$PolicyBody
    )

    $DisplayName = [string]$PolicyBody.displayName

    Write-Info "Checking for existing device configuration policy: $DisplayName"
    $ExistingPolicy = Get-DeviceConfigurationByDisplayName -DisplayName $DisplayName

    if ($ExistingPolicy) {
        Write-Warn "Policy already exists: $DisplayName"
        Write-Info "Existing Policy ID: $($ExistingPolicy.id)"

        if ($UpdateExisting) {
            Write-Info "Updating existing policy because -UpdateExisting was supplied."

            $PatchBody = $PolicyBody.Clone()
            $PatchBody.Remove("@odata.type")

            Invoke-GraphJson `
                -Method PATCH `
                -Uri "$GraphBaseUri/deviceManagement/deviceConfigurations/$($ExistingPolicy.id)" `
                -Body $PatchBody | Out-Null

            Write-Success "Updated policy: $DisplayName"
        }
        else {
            Write-Info "Leaving existing policy unchanged. Use -UpdateExisting to patch it."
        }

        return $ExistingPolicy.id
    }

    Write-Info "Creating policy: $DisplayName"

    $CreatedPolicy = Invoke-GraphJson `
        -Method POST `
        -Uri "$GraphBaseUri/deviceManagement/deviceConfigurations" `
        -Body $PolicyBody

    if (-not $CreatedPolicy -or [string]::IsNullOrWhiteSpace($CreatedPolicy.id)) {
        Write-Warn "Policy ID is blank after creation attempt for $DisplayName."
        return $null
    }

    Write-Success "Created policy: $DisplayName"
    Write-Info "Policy ID: $($CreatedPolicy.id)"

    return $CreatedPolicy.id
}

function Set-DeviceConfigurationAssignment {
    param(
        [Parameter(Mandatory)]
        [string]$PolicyId,

        [Parameter(Mandatory)]
        [string]$GroupId
    )

    if ([string]::IsNullOrWhiteSpace($PolicyId)) {
        Write-Warn "Policy ID is blank. Skipping assignment."
        return
    }

    if ($NoAssignments) {
        Write-Warn "Skipping assignment because -NoAssignments was supplied."
        return
    }

    $AssignmentBody = @{
        assignments = @(
            @{
                "@odata.type" = "#microsoft.graph.deviceConfigurationAssignment"
                target = @{
                    "@odata.type" = "#microsoft.graph.groupAssignmentTarget"
                    groupId = $GroupId
                }
            }
        )
    }

    Write-Info "Assigning policy $PolicyId to group $GroupId"

    Invoke-GraphJson `
        -Method POST `
        -Uri "$GraphBaseUri/deviceManagement/deviceConfigurations/$PolicyId/assign" `
        -Body $AssignmentBody | Out-Null

    Write-Success "Assigned policy $PolicyId to group $GroupId"
}

# -----------------------------
# OMA setting helpers
# -----------------------------

function New-OmaIntegerSetting {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Description,
        [Parameter(Mandatory)][string]$OmaUri,
        [Parameter(Mandatory)][int]$Value
    )

    return @{
        "@odata.type" = "#microsoft.graph.omaSettingInteger"
        displayName = $Name
        description = $Description
        omaUri = $OmaUri
        value = $Value
    }
}

function New-OmaStringSetting {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Description,
        [Parameter(Mandatory)][string]$OmaUri,
        [Parameter(Mandatory)][string]$Value
    )

    return @{
        "@odata.type" = "#microsoft.graph.omaSettingString"
        displayName = $Name
        description = $Description
        omaUri = $OmaUri
        value = $Value
    }
}

function Get-AsrModeValue {
    param([Parameter(Mandatory)][string]$Mode)

    switch ($Mode) {
        "Disabled" { return 0 }
        "Block"    { return 1 }
        "Audit"    { return 2 }
        "Warn"     { return 6 }
        default    { throw "Unsupported ASR mode: $Mode" }
    }
}

function New-AsrRuleString {
    param([Parameter(Mandatory)][int]$ModeValue)

    $Rules = [ordered]@{
        # Block abuse of exploited vulnerable signed drivers
        "56a863a9-875e-4185-98a7-b882c64b5ce5" = $ModeValue

        # Block credential stealing from the Windows local security authority subsystem
        "9e6c4e1f-7d60-472f-ba1a-a39ef669e4b2" = $ModeValue

        # Block Office applications from creating child processes
        "d4f940ab-401b-4efc-aadc-ad5f3c50688a" = $ModeValue

        # Block executable content from email client and webmail
        "be9ba2d9-53ea-4cdc-84e5-9b1eeee46550" = $ModeValue

        # Block Office applications from creating executable content
        "3b576869-a4ec-4529-8536-b80a7769e899" = $ModeValue

        # Block Office applications from injecting code into other processes
        "75668c1f-73b5-4cf0-bb93-3ecf5cb7cc84" = $ModeValue

        # Block JavaScript or VBScript from launching downloaded executable content
        "d3e037e1-3eb8-44c8-a917-57927947596d" = $ModeValue

        # Block execution of potentially obfuscated scripts
        "5beb7efe-fd9a-4556-801d-275e5ffc04cc" = $ModeValue

        # Block persistence through WMI event subscription
        "e6db77e5-3df2-4cf1-b95a-636979351e5b" = $ModeValue
    }

    $Pairs = foreach ($Rule in $Rules.GetEnumerator()) {
        "$($Rule.Key)=$($Rule.Value)"
    }

    return ($Pairs -join "|")
}

# -----------------------------
# Policy bodies
# -----------------------------

function New-WindowsDefenderAvPolicyBody {
    $OmaSettings = @(
        New-OmaIntegerSetting `
            -Name "Allow Real-Time Monitoring" `
            -Description "Turns on Microsoft Defender Antivirus real-time monitoring." `
            -OmaUri "./Device/Vendor/MSFT/Policy/Config/Defender/AllowRealtimeMonitoring" `
            -Value 1

        New-OmaIntegerSetting `
            -Name "Allow Behavior Monitoring" `
            -Description "Turns on Defender behavior monitoring." `
            -OmaUri "./Device/Vendor/MSFT/Policy/Config/Defender/AllowBehaviorMonitoring" `
            -Value 1

        New-OmaIntegerSetting `
            -Name "Allow Cloud Protection" `
            -Description "Turns on cloud-delivered protection." `
            -OmaUri "./Device/Vendor/MSFT/Policy/Config/Defender/AllowCloudProtection" `
            -Value 1

        New-OmaIntegerSetting `
            -Name "Allow Script Scanning" `
            -Description "Turns on script scanning." `
            -OmaUri "./Device/Vendor/MSFT/Policy/Config/Defender/AllowScriptScanning" `
            -Value 1

        New-OmaIntegerSetting `
            -Name "Allow Archive Scanning" `
            -Description "Turns on archive file scanning." `
            -OmaUri "./Device/Vendor/MSFT/Policy/Config/Defender/AllowArchiveScanning" `
            -Value 1

        New-OmaIntegerSetting `
            -Name "Allow Email Scanning" `
            -Description "Turns on email scanning." `
            -OmaUri "./Device/Vendor/MSFT/Policy/Config/Defender/AllowEmailScanning" `
            -Value 1
    )

    return @{
        "@odata.type" = "#microsoft.graph.windows10CustomConfiguration"
        displayName = "$PolicyNamePrefix-Windows-Defender-AV"
        description = "Wave 2 Endpoint Security - Microsoft Defender Antivirus baseline via OMA-URI. Created by Deploy-Wave2-EndpointSecurityPolicies-v2.ps1."
        version = 1
        omaSettings = $OmaSettings
    }
}

function New-WindowsAsrPolicyBody {
    $ModeValue = Get-AsrModeValue -Mode $AsrMode
    $AsrRules = New-AsrRuleString -ModeValue $ModeValue

    $OmaSettings = @(
        New-OmaStringSetting `
            -Name "Attack Surface Reduction Rules - $AsrMode" `
            -Description "Wave 2 ASR rules configured in $AsrMode mode. Values: 0 Disabled, 1 Block, 2 Audit, 6 Warn." `
            -OmaUri "./Vendor/MSFT/Policy/Config/Defender/AttackSurfaceReductionRules" `
            -Value $AsrRules
    )

    return @{
        "@odata.type" = "#microsoft.graph.windows10CustomConfiguration"
        displayName = "$PolicyNamePrefix-Windows-ASR-$AsrMode"
        description = "Wave 2 Endpoint Security - Attack Surface Reduction rules in $AsrMode mode via OMA-URI. Created by Deploy-Wave2-EndpointSecurityPolicies-v2.ps1."
        version = 1
        omaSettings = $OmaSettings
    }
}


function New-OmaBooleanSetting {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Description,
        [Parameter(Mandatory)][string]$OmaUri,
        [Parameter(Mandatory)][bool]$Value
    )

    return @{
        "@odata.type" = "#microsoft.graph.omaSettingBoolean"
        displayName = $Name
        description = $Description
        omaUri = $OmaUri
        value = $Value
    }
}

function New-WindowsFirewallPolicyBody {
    $Profiles = @("DomainProfile", "PrivateProfile", "PublicProfile")
    $OmaSettings = @()

    foreach ($Profile in $Profiles) {
        $FriendlyProfileName = $Profile.Replace("Profile", "")

        $OmaSettings += New-OmaBooleanSetting `
            -Name "$FriendlyProfileName Firewall - Enable Firewall" `
            -Description "Enables Microsoft Defender Firewall for the $FriendlyProfileName profile." `
            -OmaUri "./Vendor/MSFT/Firewall/MdmStore/$Profile/EnableFirewall" `
            -Value $true

        $OmaSettings += New-OmaIntegerSetting `
            -Name "$FriendlyProfileName Firewall - Default Inbound Action" `
            -Description "Sets default inbound action to Block for the $FriendlyProfileName profile. 0 Allow, 1 Block." `
            -OmaUri "./Vendor/MSFT/Firewall/MdmStore/$Profile/DefaultInboundAction" `
            -Value 1

        $OmaSettings += New-OmaIntegerSetting `
            -Name "$FriendlyProfileName Firewall - Default Outbound Action" `
            -Description "Sets default outbound action to Allow for the $FriendlyProfileName profile. 0 Allow, 1 Block." `
            -OmaUri "./Vendor/MSFT/Firewall/MdmStore/$Profile/DefaultOutboundAction" `
            -Value 0

        $OmaSettings += New-OmaBooleanSetting `
            -Name "$FriendlyProfileName Firewall - Disable Inbound Notifications" `
            -Description "Disables user notifications when applications are blocked from receiving inbound connections." `
            -OmaUri "./Vendor/MSFT/Firewall/MdmStore/$Profile/DisableInboundNotifications" `
            -Value $true
    }

    return @{
        "@odata.type" = "#microsoft.graph.windows10CustomConfiguration"
        displayName = "$PolicyNamePrefix-Windows-Firewall"
        description = "Wave 2 Endpoint Security - Windows Defender Firewall baseline via Firewall CSP. Created by Deploy-Wave2-EndpointSecurityPolicies-v2.ps1."
        version = 1
        omaSettings = $OmaSettings
    }
}

function New-WindowsBitLockerPolicyBody {
    <#
        Safe core BitLocker baseline.

        This intentionally avoids the more complex ADMX-backed BitLocker settings such as:
          - SystemDrivesRecoveryOptions
          - FixedDrivesRecoveryOptions
          - EncryptionMethodByDriveType

        Those require chr/XML payloads and should be deployed after a validated export.
    #>

    $OmaSettings = @(
        New-OmaIntegerSetting `
            -Name "BitLocker - Allow Warning For Other Disk Encryption" `
            -Description "Suppresses warning for other disk encryption to support silent encryption. 0 = warning disabled / silent encryption allowed." `
            -OmaUri "./Device/Vendor/MSFT/BitLocker/AllowWarningForOtherDiskEncryption" `
            -Value 0

        New-OmaIntegerSetting `
            -Name "BitLocker - Allow Standard User Encryption" `
            -Description "Allows RequireDeviceEncryption to enable encryption for a standard user on Microsoft Entra joined devices." `
            -OmaUri "./Device/Vendor/MSFT/BitLocker/AllowStandardUserEncryption" `
            -Value 1

        New-OmaIntegerSetting `
            -Name "BitLocker - Require Device Encryption" `
            -Description "Requires device encryption on supported Windows devices." `
            -OmaUri "./Device/Vendor/MSFT/BitLocker/RequireDeviceEncryption" `
            -Value 1
    )

    return @{
        "@odata.type" = "#microsoft.graph.windows10CustomConfiguration"
        displayName = "$PolicyNamePrefix-Windows-BitLocker"
        description = "Wave 2 Endpoint Security - safe core BitLocker baseline via BitLocker CSP. Created by Deploy-Wave2-EndpointSecurityPolicies-v2.ps1."
        version = 1
        omaSettings = $OmaSettings
    }
}


# -----------------------------
# Main
# -----------------------------

Write-Section "Wave 2 Endpoint Security Policy Deployment"

Write-Info "Policy prefix: $PolicyNamePrefix"
Write-Info "Target group ID: $TargetGroupId"
Write-Info "ASR mode: $AsrMode"
Write-Info "Include ASR custom OMA-URI policy: $($IncludeASRCustomPolicy.IsPresent)"
if (-not $IncludeASRCustomPolicy) {
    Write-Warn "ASR custom OMA-URI policy will be skipped. Recommended production target: Defender-native ASR policy for SOC visibility and tuning."
}
Write-Info "Update existing policies: $($UpdateExisting.IsPresent)"
Write-Info "Skip assignments: $($NoAssignments.IsPresent)"
Write-Info "WhatIfOnly: $($WhatIfOnly.IsPresent)"

if (-not $WhatIfOnly) {
    Connect-ToGraph
}
else {
    Ensure-GraphAuthenticationModule
    Write-Warn "WHATIF mode enabled. No Graph changes will be made."
}

$CreatedPolicyIds = [ordered]@{}

Write-Section "Windows Defender Antivirus baseline"

try {
    $DefenderPolicyBody = New-WindowsDefenderAvPolicyBody
    $DefenderPolicyId = New-OrUpdate-DeviceConfiguration -PolicyBody $DefenderPolicyBody
    $CreatedPolicyIds["$PolicyNamePrefix-Windows-Defender-AV"] = $DefenderPolicyId

    if ($DefenderPolicyId) {
        Set-DeviceConfigurationAssignment -PolicyId $DefenderPolicyId -GroupId $TargetGroupId
    }
}
catch {
    Write-Fail "Windows Defender AV policy deployment failed."
}

if ($IncludeASRCustomPolicy) {
    Write-Section "Windows Attack Surface Reduction baseline (custom OMA-URI)"

    try {
        $AsrPolicyBody = New-WindowsAsrPolicyBody
        $AsrPolicyId = New-OrUpdate-DeviceConfiguration -PolicyBody $AsrPolicyBody
        $CreatedPolicyIds["$PolicyNamePrefix-Windows-ASR-$AsrMode"] = $AsrPolicyId

        if ($AsrPolicyId) {
            Set-DeviceConfigurationAssignment -PolicyId $AsrPolicyId -GroupId $TargetGroupId
        }
    }
    catch {
        Write-Fail "Windows ASR policy deployment failed."
    }
}
else {
    Write-Section "Windows Attack Surface Reduction baseline"
    Write-Warn "Skipped ASR custom OMA-URI deployment. Create/manage ASR using Defender-native policy for production operational visibility."
}

Write-Section "Windows Firewall baseline"

try {
    $FirewallPolicyBody = New-WindowsFirewallPolicyBody
    $FirewallPolicyId = New-OrUpdate-DeviceConfiguration -PolicyBody $FirewallPolicyBody
    $CreatedPolicyIds["$PolicyNamePrefix-Windows-Firewall"] = $FirewallPolicyId

    if ($FirewallPolicyId) {
        Set-DeviceConfigurationAssignment -PolicyId $FirewallPolicyId -GroupId $TargetGroupId
    }
}
catch {
    Write-Fail "Windows Firewall policy deployment failed."
}

Write-Section "Windows BitLocker baseline"

try {
    $BitLockerPolicyBody = New-WindowsBitLockerPolicyBody
    $BitLockerPolicyId = New-OrUpdate-DeviceConfiguration -PolicyBody $BitLockerPolicyBody
    $CreatedPolicyIds["$PolicyNamePrefix-Windows-BitLocker"] = $BitLockerPolicyId

    if ($BitLockerPolicyId) {
        Set-DeviceConfigurationAssignment -PolicyId $BitLockerPolicyId -GroupId $TargetGroupId
    }
}
catch {
    Write-Fail "Windows BitLocker policy deployment failed."
}

Write-Section "Not deployed by this v2 script"

Write-Warn "macOS Defender, macOS FileVault and macOS Firewall are intentionally not deployed in this Windows-focused pass."
Write-Warn "Reason: macOS Defender requires onboarding, system extension, network filter and PPPC payloads."
Write-Warn "Next build step: create macOS profile payload pack for:"
Write-Host "  - W2-SEC-macOS-Defender"
Write-Host "  - W2-SEC-macOS-FileVault"
Write-Host "  - W2-SEC-macOS-Firewall"

Write-Section "Deployment summary"

foreach ($Policy in $CreatedPolicyIds.GetEnumerator()) {
    Write-Host "$($Policy.Key): $($Policy.Value)"
}

Write-Host ""
Write-Success "Wave 2 endpoint security policy deployment complete."

Write-Host ""
Write-Info "Suggested pilot run:"
Write-Host ".\Deploy-Wave2-EndpointSecurityPolicies-v2.ps1 -TenantId `"<tenant-id>`" -PilotGroupId `"$TargetGroupId`" -AsrMode Audit -ShowJson"
