# Wave 2 PowerShell Script Pack

This pack contains the regenerated scripts referenced in the Wave 2 document.

## Included scripts

| Script | Purpose |
|---|---|
| Deploy-Wave2-CompliancePolicies-v3.7.ps1 | Deploys Windows and macOS compliance policies. |
| Deploy-Wave2-EndpointSecurityPolicies-v2.1.ps1 | Deploys Windows Defender AV, Firewall and BitLocker. ASR custom OMA-URI is optional. |
| Deploy-Wave2-macOS-DefenderProfiles-v1.ps1 | Deploys macOS Defender configuration profiles. |
| Deploy-Wave2-macOS-FileVaultFirewall-v1.ps1 | Deploys macOS FileVault and Firewall profiles. |
| Validate-Wave2-EndpointSecurity-v1.4.ps1 | Validates policy existence, assignments, compliance, encryption and device posture. |
| Export-DefenderVulnerabilityManagement.ps1 | Exports Defender Vulnerability Management data for reporting. |
| Invoke-Wave2-MultiTenantOrchestrator.ps1 | Runs the deployment/validation flow across tenants. |

## Important ASR update

The Windows endpoint security script has been regenerated as `v2.1`.

By default, it **does not deploy ASR via custom OMA-URI**. This aligns to the workshop decision that ASR should be managed through Defender-native policy for SOC visibility, tuning, and operational ownership.

Use `-IncludeASRCustomPolicy` only for lab/testing or where a custom OMA-URI ASR deployment is explicitly required.

## Example: Windows endpoint security without ASR custom policy

```powershell
.\Deploy-Wave2-EndpointSecurityPolicies-v2.1.ps1 `
  -TenantId "<tenant-id>" `
  -PilotGroupId "<group-id>" `
  -ShowJson
```

## Example: Optional ASR custom policy

```powershell
.\Deploy-Wave2-EndpointSecurityPolicies-v2.1.ps1 `
  -TenantId "<tenant-id>" `
  -PilotGroupId "<group-id>" `
  -AsrMode Audit `
  -IncludeASRCustomPolicy `
  -ShowJson
```

## Recommended production model

| Control | Recommended management location |
|---|---|
| Compliance | Intune Compliance Policies |
| Conditional Access | Entra ID |
| ASR | Defender-native policy |
| Defender AV baseline | Intune/Defender native policy where operational visibility is required |
| Windows Firewall / BitLocker | Intune Endpoint Security / Settings Catalog preferred; CSP used where automation requires precision |
| macOS Defender system extensions / PPPC / onboarding | macOS configuration profiles, as required by Apple/MDE deployment model |
