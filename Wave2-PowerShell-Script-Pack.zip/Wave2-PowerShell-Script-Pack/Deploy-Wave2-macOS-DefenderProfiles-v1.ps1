<#
.SYNOPSIS
    Deploys Wave 2 macOS Microsoft Defender for Endpoint onboarding profiles using Microsoft Graph.

.DESCRIPTION
    Creates or reuses macOS custom configuration profiles for Microsoft Defender for Endpoint:

      - W2-SEC-macOS-Defender-SystemExtensions
      - W2-SEC-macOS-Defender-NetworkFilter
      - W2-SEC-macOS-Defender-FullDiskAccess
      - W2-SEC-macOS-Defender-Preferences
      - W2-SEC-macOS-Defender-Onboarding

    The onboarding profile requires the onboarding XML downloaded from Microsoft Defender XDR:
      Settings > Endpoints > Onboarding > macOS > Mobile Device Management / Microsoft Intune

    This script uses Microsoft Graph deviceManagement/deviceConfigurations with
    #microsoft.graph.macOSCustomConfiguration payloads.

.REQUIREMENTS
    PowerShell 7 recommended.
    Microsoft.Graph.Authentication module.

.GRAPH PERMISSIONS
    DeviceManagementConfiguration.ReadWrite.All
    Directory.Read.All

.EXAMPLE
    .\Deploy-Wave2-macOS-DefenderProfiles-v1.ps1 `
      -TenantId "00000000-0000-0000-0000-000000000000" `
      -PilotGroupId "533187c7-4628-47c3-bbc7-0d204def0f57" `
      -OnboardingXmlPath "C:\Temp\WindowsDefenderATPOnboarding__MDATP_wdav.atp.xml" `
      -ShowJson

.NOTES
    The payloads are based on Microsoft's documented macOS MDE Intune deployment model:
      - System extension approval
      - Network extension/filter approval
      - Full Disk Access / PPPC
      - Defender preferences
      - Onboarding XML

    Validate in a pilot before production rollout.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$TenantId,

    [Parameter(Mandatory = $true)]
    [Alias("PilotGroupId")]
    [ValidatePattern('^[0-9a-fA-F-]{36}$')]
    [string]$TargetGroupId,

    [Parameter(Mandatory = $true)]
    [ValidateScript({ Test-Path $_ })]
    [string]$OnboardingXmlPath,

    [Parameter(Mandatory = $false)]
    [string]$PolicyNamePrefix = "W2-SEC",

    [Parameter(Mandatory = $false)]
    [switch]$PassiveMode,

    [Parameter(Mandatory = $false)]
    [switch]$UpdateExisting,

    [Parameter(Mandatory = $false)]
    [switch]$NoAssignments,

    [Parameter(Mandatory = $false)]
    [switch]$WhatIfOnly,

    [Parameter(Mandatory = $false)]
    [switch]$ShowJson
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$GraphBaseUri = "https://graph.microsoft.com/v1.0"

# Microsoft Team ID used by Microsoft Defender for Endpoint on macOS profiles.
$MicrosoftTeamId = "UBF8T346G9"

# -----------------------------
# Logging
# -----------------------------

function Write-Section {
    param([Parameter(Mandatory)][string]$Message)

    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host $Message -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
}

function Write-Info { param([Parameter(Mandatory)][string]$Message) Write-Host "[INFO] $Message" -ForegroundColor White }
function Write-Success { param([Parameter(Mandatory)][string]$Message) Write-Host "[OK]   $Message" -ForegroundColor Green }
function Write-Warn { param([Parameter(Mandatory)][string]$Message) Write-Host "[WARN] $Message" -ForegroundColor Yellow }
function Write-Fail { param([Parameter(Mandatory)][string]$Message) Write-Host "[FAIL] $Message" -ForegroundColor Red }

# -----------------------------
# Graph helpers
# -----------------------------

function Ensure-GraphAuthenticationModule {
    if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Authentication)) {
        Write-Warn "Microsoft.Graph.Authentication module is not installed."
        Write-Info "Installing Microsoft.Graph.Authentication for current user..."
        Install-Module Microsoft.Graph.Authentication -Scope CurrentUser -Force -AllowClobber
    }

    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
}

function Connect-ToGraph {
    Ensure-GraphAuthenticationModule

    $Scopes = @(
        "DeviceManagementConfiguration.ReadWrite.All",
        "Directory.Read.All"
    )

    $ExistingContext = Get-MgContext -ErrorAction SilentlyContinue

    if ($ExistingContext) {
        Write-Info "Existing Graph context detected for tenant $($ExistingContext.TenantId)."

        if ($TenantId -and ($ExistingContext.TenantId -ne $TenantId)) {
            Write-Warn "Connected tenant does not match requested tenant. Reconnecting..."
            Disconnect-MgGraph | Out-Null
            $ExistingContext = $null
        }
    }

    if (-not $ExistingContext) {
        if ($TenantId) {
            Write-Info "Connecting to Microsoft Graph tenant $TenantId..."
            Connect-MgGraph -TenantId $TenantId -Scopes $Scopes -NoWelcome | Out-Null
        }
        else {
            Write-Info "Connecting to Microsoft Graph..."
            Connect-MgGraph -Scopes $Scopes -NoWelcome | Out-Null
        }
    }

    $Context = Get-MgContext

    if (-not $Context) {
        throw "Could not establish Microsoft Graph context."
    }

    Write-Success "Connected to tenant $($Context.TenantId) as $($Context.Account)."
}

function ConvertTo-GraphJson {
    param([Parameter(Mandatory)]$Body)
    return ($Body | ConvertTo-Json -Depth 80)
}

function Get-GraphErrorText {
    param([Parameter(Mandatory)]$ErrorRecord)

    if ($ErrorRecord.ErrorDetails -and $ErrorRecord.ErrorDetails.Message) {
        return $ErrorRecord.ErrorDetails.Message
    }

    return $ErrorRecord.Exception.Message
}

function Invoke-GraphJson {
    param(
        [Parameter(Mandatory)]
        [ValidateSet("GET", "POST", "PATCH", "DELETE")]
        [string]$Method,

        [Parameter(Mandatory)]
        [string]$Uri,

        [Parameter(Mandatory = $false)]
        $Body
    )

    try {
        if ($PSBoundParameters.ContainsKey("Body") -and $null -ne $Body) {
            $Json = ConvertTo-GraphJson -Body $Body

            if ($ShowJson -or $WhatIfOnly) {
                Write-Host ""
                Write-Host "JSON PAYLOAD: $Method $Uri" -ForegroundColor DarkCyan
                Write-Host $Json
            }

            if ($WhatIfOnly) {
                return $null
            }

            return Invoke-MgGraphRequest `
                -Method $Method `
                -Uri $Uri `
                -Body $Json `
                -ContentType "application/json"
        }

        if ($WhatIfOnly) {
            Write-Host "WHATIF: $Method $Uri" -ForegroundColor Magenta
            return $null
        }

        return Invoke-MgGraphRequest -Method $Method -Uri $Uri
    }
    catch {
        Write-Fail "$Method $Uri failed."
        Write-Host (Get-GraphErrorText -ErrorRecord $_) -ForegroundColor Red
        throw
    }
}

function Escape-ODataString {
    param([Parameter(Mandatory)][string]$Value)
    return $Value.Replace("'", "''")
}

# -----------------------------
# macOS Custom Configuration helpers
# -----------------------------

function Get-DeviceConfigurationByDisplayName {
    param([Parameter(Mandatory)][string]$DisplayName)

    $EscapedName = Escape-ODataString -Value $DisplayName
    $Uri = "$GraphBaseUri/deviceManagement/deviceConfigurations?`$filter=displayName eq '$EscapedName'"

    $Response = Invoke-GraphJson -Method GET -Uri $Uri

    if ($Response -and $Response.value -and $Response.value.Count -gt 0) {
        return $Response.value[0]
    }

    return $null
}

function ConvertTo-Base64Utf8 {
    param([Parameter(Mandatory)][string]$Content)

    $Bytes = [System.Text.Encoding]::UTF8.GetBytes($Content)
    return [System.Convert]::ToBase64String($Bytes)
}

function New-MacOSCustomConfigurationBody {
    param(
        [Parameter(Mandatory)][string]$DisplayName,
        [Parameter(Mandatory)][string]$Description,
        [Parameter(Mandatory)][string]$PayloadName,
        [Parameter(Mandatory)][string]$PayloadFileName,
        [Parameter(Mandatory)][string]$PayloadContent
    )

    return @{
        "@odata.type" = "#microsoft.graph.macOSCustomConfiguration"
        displayName = $DisplayName
        description = $Description
        version = 1
        payloadName = $PayloadName
        payloadFileName = $PayloadFileName
        payload = (ConvertTo-Base64Utf8 -Content $PayloadContent)
    }
}

function New-OrUpdate-MacOSCustomConfiguration {
    param(
        [Parameter(Mandatory)]
        [hashtable]$PolicyBody
    )

    $DisplayName = [string]$PolicyBody.displayName

    Write-Info "Checking for existing macOS custom configuration: $DisplayName"
    $ExistingPolicy = Get-DeviceConfigurationByDisplayName -DisplayName $DisplayName

    if ($ExistingPolicy) {
        Write-Warn "Policy already exists: $DisplayName"
        Write-Info "Existing Policy ID: $($ExistingPolicy.id)"

        if ($UpdateExisting) {
            Write-Info "Updating existing policy because -UpdateExisting was supplied."

            $PatchBody = $PolicyBody.Clone()
            $PatchBody.Remove("@odata.type")

            Invoke-GraphJson `
                -Method PATCH `
                -Uri "$GraphBaseUri/deviceManagement/deviceConfigurations/$($ExistingPolicy.id)" `
                -Body $PatchBody | Out-Null

            Write-Success "Updated policy: $DisplayName"
        }
        else {
            Write-Info "Leaving existing policy unchanged. Use -UpdateExisting to patch it."
        }

        return $ExistingPolicy.id
    }

    Write-Info "Creating policy: $DisplayName"

    $CreatedPolicy = Invoke-GraphJson `
        -Method POST `
        -Uri "$GraphBaseUri/deviceManagement/deviceConfigurations" `
        -Body $PolicyBody

    if (-not $CreatedPolicy -or [string]::IsNullOrWhiteSpace($CreatedPolicy.id)) {
        Write-Warn "Policy ID is blank after creation attempt for $DisplayName."
        return $null
    }

    Write-Success "Created policy: $DisplayName"
    Write-Info "Policy ID: $($CreatedPolicy.id)"

    return $CreatedPolicy.id
}

function Set-DeviceConfigurationAssignment {
    param(
        [Parameter(Mandatory)][string]$PolicyId,
        [Parameter(Mandatory)][string]$GroupId
    )

    if ([string]::IsNullOrWhiteSpace($PolicyId)) {
        Write-Warn "Policy ID is blank. Skipping assignment."
        return
    }

    if ($NoAssignments) {
        Write-Warn "Skipping assignment because -NoAssignments was supplied."
        return
    }

    $AssignmentBody = @{
        assignments = @(
            @{
                "@odata.type" = "#microsoft.graph.deviceConfigurationAssignment"
                target = @{
                    "@odata.type" = "#microsoft.graph.groupAssignmentTarget"
                    groupId = $GroupId
                }
            }
        )
    }

    Write-Info "Assigning policy $PolicyId to group $GroupId"

    Invoke-GraphJson `
        -Method POST `
        -Uri "$GraphBaseUri/deviceManagement/deviceConfigurations/$PolicyId/assign" `
        -Body $AssignmentBody | Out-Null

    Write-Success "Assigned policy $PolicyId to group $GroupId"
}

# -----------------------------
# Payload builders
# -----------------------------

function New-MobileConfig {
    param(
        [Parameter(Mandatory)][string]$PayloadIdentifier,
        [Parameter(Mandatory)][string]$PayloadDisplayName,
        [Parameter(Mandatory)][string]$PayloadContentXml
    )

    $PayloadUuid = [guid]::NewGuid().Guid.ToUpper()
    $TopUuid = [guid]::NewGuid().Guid.ToUpper()

    return @"
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>PayloadContent</key>
    <array>
$PayloadContentXml
    </array>
    <key>PayloadDisplayName</key>
    <string>$PayloadDisplayName</string>
    <key>PayloadIdentifier</key>
    <string>$PayloadIdentifier</string>
    <key>PayloadOrganization</key>
    <string>Wave 2 Endpoint Security</string>
    <key>PayloadRemovalDisallowed</key>
    <true/>
    <key>PayloadScope</key>
    <string>System</string>
    <key>PayloadType</key>
    <string>Configuration</string>
    <key>PayloadUUID</key>
    <string>$TopUuid</string>
    <key>PayloadVersion</key>
    <integer>1</integer>
</dict>
</plist>
"@
}

function New-SystemExtensionsPayload {
    $InnerUuid = [guid]::NewGuid().Guid.ToUpper()

    $Inner = @"
        <dict>
            <key>AllowedSystemExtensions</key>
            <dict>
                <key>$MicrosoftTeamId</key>
                <array>
                    <string>com.microsoft.wdav.epsext</string>
                    <string>com.microsoft.wdav.netext</string>
                </array>
            </dict>
            <key>PayloadDescription</key>
            <string>Approves Microsoft Defender for Endpoint system extensions.</string>
            <key>PayloadDisplayName</key>
            <string>Microsoft Defender System Extensions</string>
            <key>PayloadIdentifier</key>
            <string>com.atech.wave2.mde.systemextensions.payload</string>
            <key>PayloadOrganization</key>
            <string>Wave 2 Endpoint Security</string>
            <key>PayloadType</key>
            <string>com.apple.system-extension-policy</string>
            <key>PayloadUUID</key>
            <string>$InnerUuid</string>
            <key>PayloadVersion</key>
            <integer>1</integer>
        </dict>
"@

    return New-MobileConfig `
        -PayloadIdentifier "com.atech.wave2.mde.systemextensions" `
        -PayloadDisplayName "Microsoft Defender System Extensions" `
        -PayloadContentXml $Inner
}

function New-NetworkFilterPayload {
    $InnerUuid = [guid]::NewGuid().Guid.ToUpper()

    $Inner = @"
        <dict>
            <key>FilterBrowsers</key>
            <true/>
            <key>FilterDataProviderBundleIdentifier</key>
            <string>com.microsoft.wdav.netext</string>
            <key>FilterDataProviderDesignatedRequirement</key>
            <string>identifier "com.microsoft.wdav.netext" and anchor apple generic and certificate leaf[subject.OU] = "$MicrosoftTeamId"</string>
            <key>FilterGrade</key>
            <string>firewall</string>
            <key>FilterPackets</key>
            <false/>
            <key>FilterSockets</key>
            <true/>
            <key>FilterType</key>
            <string>Plugin</string>
            <key>PayloadDescription</key>
            <string>Approves Microsoft Defender for Endpoint network filter.</string>
            <key>PayloadDisplayName</key>
            <string>Microsoft Defender Network Filter</string>
            <key>PayloadIdentifier</key>
            <string>com.atech.wave2.mde.networkfilter.payload</string>
            <key>PayloadOrganization</key>
            <string>Wave 2 Endpoint Security</string>
            <key>PayloadType</key>
            <string>com.apple.webcontent-filter</string>
            <key>PayloadUUID</key>
            <string>$InnerUuid</string>
            <key>PayloadVersion</key>
            <integer>1</integer>
            <key>PluginBundleID</key>
            <string>com.microsoft.wdav.netext</string>
            <key>UserDefinedName</key>
            <string>Microsoft Defender Network Extension</string>
        </dict>
"@

    return New-MobileConfig `
        -PayloadIdentifier "com.atech.wave2.mde.networkfilter" `
        -PayloadDisplayName "Microsoft Defender Network Filter" `
        -PayloadContentXml $Inner
}

function New-FullDiskAccessPayload {
    $InnerUuid = [guid]::NewGuid().Guid.ToUpper()

    $Inner = @"
        <dict>
            <key>PayloadDescription</key>
            <string>Grants required privacy permissions for Microsoft Defender for Endpoint.</string>
            <key>PayloadDisplayName</key>
            <string>Microsoft Defender Full Disk Access</string>
            <key>PayloadIdentifier</key>
            <string>com.atech.wave2.mde.fulldiskaccess.payload</string>
            <key>PayloadOrganization</key>
            <string>Wave 2 Endpoint Security</string>
            <key>PayloadType</key>
            <string>com.apple.TCC.configuration-profile-policy</string>
            <key>PayloadUUID</key>
            <string>$InnerUuid</string>
            <key>PayloadVersion</key>
            <integer>1</integer>
            <key>Services</key>
            <dict>
                <key>SystemPolicyAllFiles</key>
                <array>
                    <dict>
                        <key>Allowed</key>
                        <true/>
                        <key>CodeRequirement</key>
                        <string>identifier "com.microsoft.wdav" and anchor apple generic and certificate leaf[subject.OU] = "$MicrosoftTeamId"</string>
                        <key>Identifier</key>
                        <string>com.microsoft.wdav</string>
                        <key>IdentifierType</key>
                        <string>bundleID</string>
                    </dict>
                    <dict>
                        <key>Allowed</key>
                        <true/>
                        <key>CodeRequirement</key>
                        <string>identifier "com.microsoft.wdav.epsext" and anchor apple generic and certificate leaf[subject.OU] = "$MicrosoftTeamId"</string>
                        <key>Identifier</key>
                        <string>com.microsoft.wdav.epsext</string>
                        <key>IdentifierType</key>
                        <string>bundleID</string>
                    </dict>
                </array>
            </dict>
        </dict>
"@

    return New-MobileConfig `
        -PayloadIdentifier "com.atech.wave2.mde.fulldiskaccess" `
        -PayloadDisplayName "Microsoft Defender Full Disk Access" `
        -PayloadContentXml $Inner
}

function New-DefenderPreferencesPayload {
    $PassiveModeString = if ($PassiveMode) { "true" } else { "false" }

    return @"
<?xml version="1.0" encoding="UTF-8"?>
<dict>
    <key>antivirusEngine</key>
    <dict>
        <key>enforcementLevel</key>
        <string>real_time</string>
        <key>behaviorMonitoring</key>
        <string>enabled</string>
        <key>passiveMode</key>
        <$PassiveModeString/>
    </dict>
    <key>cloudService</key>
    <dict>
        <key>enabled</key>
        <true/>
        <key>automaticSampleSubmission</key>
        <true/>
    </dict>
    <key>edr</key>
    <dict>
        <key>tags</key>
        <array>
            <dict>
                <key>key</key>
                <string>GROUP</string>
                <key>value</key>
                <string>Wave2-macOS-Pilot</string>
            </dict>
        </array>
    </dict>
    <key>features</key>
    <dict>
        <key>hideStatusMenuIcon</key>
        <false/>
    </dict>
</dict>
"@
}

function New-OnboardingPayload {
    $Content = Get-Content -Path $OnboardingXmlPath -Raw -Encoding UTF8
    return $Content
}

# -----------------------------
# Main
# -----------------------------

Write-Section "Wave 2 macOS Defender for Endpoint Profile Deployment"

Write-Info "Target group ID: $TargetGroupId"
Write-Info "Onboarding XML: $OnboardingXmlPath"
Write-Info "Passive mode: $($PassiveMode.IsPresent)"
Write-Info "Update existing policies: $($UpdateExisting.IsPresent)"
Write-Info "Skip assignments: $($NoAssignments.IsPresent)"
Write-Info "WhatIfOnly: $($WhatIfOnly.IsPresent)"

if (-not $WhatIfOnly) {
    Connect-ToGraph
}
else {
    Ensure-GraphAuthenticationModule
    Write-Warn "WHATIF mode enabled. No Graph changes will be made."
}

$CreatedPolicyIds = [ordered]@{}

$Profiles = @(
    @{
        DisplayName = "$PolicyNamePrefix-macOS-Defender-SystemExtensions"
        Description = "Wave 2 macOS Defender - approves Microsoft Defender system extensions."
        PayloadName = "Microsoft Defender System Extensions"
        PayloadFileName = "W2-SEC-macOS-Defender-SystemExtensions.mobileconfig"
        PayloadContent = (New-SystemExtensionsPayload)
    },
    @{
        DisplayName = "$PolicyNamePrefix-macOS-Defender-NetworkFilter"
        Description = "Wave 2 macOS Defender - approves Microsoft Defender network filter."
        PayloadName = "Microsoft Defender Network Filter"
        PayloadFileName = "W2-SEC-macOS-Defender-NetworkFilter.mobileconfig"
        PayloadContent = (New-NetworkFilterPayload)
    },
    @{
        DisplayName = "$PolicyNamePrefix-macOS-Defender-FullDiskAccess"
        Description = "Wave 2 macOS Defender - grants Full Disk Access/PPPC permissions."
        PayloadName = "Microsoft Defender Full Disk Access"
        PayloadFileName = "W2-SEC-macOS-Defender-FullDiskAccess.mobileconfig"
        PayloadContent = (New-FullDiskAccessPayload)
    },
    @{
        DisplayName = "$PolicyNamePrefix-macOS-Defender-Preferences"
        Description = "Wave 2 macOS Defender - configures Defender preferences."
        PayloadName = "com.microsoft.wdav"
        PayloadFileName = "com.microsoft.wdav.xml"
        PayloadContent = (New-DefenderPreferencesPayload)
    },
    @{
        DisplayName = "$PolicyNamePrefix-macOS-Defender-Onboarding"
        Description = "Wave 2 macOS Defender - onboarding profile from Microsoft Defender XDR."
        PayloadName = "com.microsoft.wdav.atp"
        PayloadFileName = "WindowsDefenderATPOnboarding__MDATP_wdav.atp.xml"
        PayloadContent = (New-OnboardingPayload)
    }
)

foreach ($Profile in $Profiles) {
    Write-Section $Profile.DisplayName

    try {
        $PolicyBody = New-MacOSCustomConfigurationBody `
            -DisplayName $Profile.DisplayName `
            -Description $Profile.Description `
            -PayloadName $Profile.PayloadName `
            -PayloadFileName $Profile.PayloadFileName `
            -PayloadContent $Profile.PayloadContent

        $PolicyId = New-OrUpdate-MacOSCustomConfiguration -PolicyBody $PolicyBody
        $CreatedPolicyIds[$Profile.DisplayName] = $PolicyId

        if ($PolicyId) {
            Set-DeviceConfigurationAssignment -PolicyId $PolicyId -GroupId $TargetGroupId
        }
    }
    catch {
        Write-Fail "Deployment failed for $($Profile.DisplayName)."
    }
}

Write-Section "Deployment summary"

foreach ($Policy in $CreatedPolicyIds.GetEnumerator()) {
    Write-Host "$($Policy.Key): $($Policy.Value)"
}

Write-Host ""
Write-Success "Wave 2 macOS Defender profile deployment complete."

Write-Host ""
Write-Warn "Remember: the Microsoft Defender for Endpoint app package itself still needs to be deployed to macOS devices."
Write-Warn "This script deploys the configuration profiles and onboarding payload, not the Wdav.pkg app."
