<#
.SYNOPSIS
    Deploys Wave 2 macOS FileVault and Firewall profiles using Microsoft Graph.

.DESCRIPTION
    Creates or reuses macOS custom configuration profiles for:

      - W2-SEC-macOS-Firewall
      - W2-SEC-macOS-FileVault

    This script uses Microsoft Graph deviceManagement/deviceConfigurations with
    #microsoft.graph.macOSCustomConfiguration payloads.

.IMPORTANT
    macOS Firewall is suitable for custom mobileconfig deployment.

    FileVault enforcement can be deployed through a custom mobileconfig, but Intune recovery
    key escrow and rotation are best handled using Intune's native Endpoint Security >
    Disk Encryption or Settings Catalog FileVault policy.

    Use this script for pilot baseline deployment/testing. For production FileVault escrow,
    validate that recovery keys are visible in Intune before broad rollout.

.REQUIREMENTS
    PowerShell 7 recommended.
    Microsoft.Graph.Authentication module.

.GRAPH PERMISSIONS
    DeviceManagementConfiguration.ReadWrite.All
    Directory.Read.All

.EXAMPLE
    .\Deploy-Wave2-macOS-FileVaultFirewall-v1.ps1 `
      -TenantId "00000000-0000-0000-0000-000000000000" `
      -PilotGroupId "533187c7-4628-47c3-bbc7-0d204def0f57" `
      -EscrowLocation "Atech Service Desk" `
      -ShowJson

.EXAMPLE
    Preview without deploying:

    .\Deploy-Wave2-macOS-FileVaultFirewall-v1.ps1 `
      -TenantId "00000000-0000-0000-0000-000000000000" `
      -PilotGroupId "533187c7-4628-47c3-bbc7-0d204def0f57" `
      -WhatIfOnly `
      -ShowJson
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$TenantId,

    [Parameter(Mandatory = $true)]
    [Alias("PilotGroupId")]
    [ValidatePattern('^[0-9a-fA-F-]{36}$')]
    [string]$TargetGroupId,

    [Parameter(Mandatory = $false)]
    [string]$PolicyNamePrefix = "W2-SEC",

    [Parameter(Mandatory = $false)]
    [string]$EscrowLocation = "IT Service Desk",

    [Parameter(Mandatory = $false)]
    [ValidateRange(0, 10)]
    [int]$FileVaultBypassAttempts = 0,

    [Parameter(Mandatory = $false)]
    [switch]$DisableFileVaultAtSetupAssistant,

    [Parameter(Mandatory = $false)]
    [switch]$AllowFileVaultDisable,

    [Parameter(Mandatory = $false)]
    [switch]$BlockAllIncomingFirewallConnections,

    [Parameter(Mandatory = $false)]
    [switch]$UpdateExisting,

    [Parameter(Mandatory = $false)]
    [switch]$NoAssignments,

    [Parameter(Mandatory = $false)]
    [switch]$WhatIfOnly,

    [Parameter(Mandatory = $false)]
    [switch]$ShowJson
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$GraphBaseUri = "https://graph.microsoft.com/v1.0"

# -----------------------------
# Logging
# -----------------------------

function Write-Section {
    param([Parameter(Mandatory)][string]$Message)

    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host $Message -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
}

function Write-Info { param([Parameter(Mandatory)][string]$Message) Write-Host "[INFO] $Message" -ForegroundColor White }
function Write-Success { param([Parameter(Mandatory)][string]$Message) Write-Host "[OK]   $Message" -ForegroundColor Green }
function Write-Warn { param([Parameter(Mandatory)][string]$Message) Write-Host "[WARN] $Message" -ForegroundColor Yellow }
function Write-Fail { param([Parameter(Mandatory)][string]$Message) Write-Host "[FAIL] $Message" -ForegroundColor Red }

# -----------------------------
# Graph helpers
# -----------------------------

function Ensure-GraphAuthenticationModule {
    if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Authentication)) {
        Write-Warn "Microsoft.Graph.Authentication module is not installed."
        Write-Info "Installing Microsoft.Graph.Authentication for current user..."
        Install-Module Microsoft.Graph.Authentication -Scope CurrentUser -Force -AllowClobber
    }

    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
}

function Connect-ToGraph {
    Ensure-GraphAuthenticationModule

    $Scopes = @(
        "DeviceManagementConfiguration.ReadWrite.All",
        "Directory.Read.All"
    )

    $ExistingContext = Get-MgContext -ErrorAction SilentlyContinue

    if ($ExistingContext) {
        Write-Info "Existing Graph context detected for tenant $($ExistingContext.TenantId)."

        if ($TenantId -and ($ExistingContext.TenantId -ne $TenantId)) {
            Write-Warn "Connected tenant does not match requested tenant. Reconnecting..."
            Disconnect-MgGraph | Out-Null
            $ExistingContext = $null
        }
    }

    if (-not $ExistingContext) {
        if ($TenantId) {
            Write-Info "Connecting to Microsoft Graph tenant $TenantId..."
            Connect-MgGraph -TenantId $TenantId -Scopes $Scopes -NoWelcome | Out-Null
        }
        else {
            Write-Info "Connecting to Microsoft Graph..."
            Connect-MgGraph -Scopes $Scopes -NoWelcome | Out-Null
        }
    }

    $Context = Get-MgContext

    if (-not $Context) {
        throw "Could not establish Microsoft Graph context."
    }

    Write-Success "Connected to tenant $($Context.TenantId) as $($Context.Account)."
}

function ConvertTo-GraphJson {
    param([Parameter(Mandatory)]$Body)
    return ($Body | ConvertTo-Json -Depth 80)
}

function Get-GraphErrorText {
    param([Parameter(Mandatory)]$ErrorRecord)

    if ($ErrorRecord.ErrorDetails -and $ErrorRecord.ErrorDetails.Message) {
        return $ErrorRecord.ErrorDetails.Message
    }

    return $ErrorRecord.Exception.Message
}

function Invoke-GraphJson {
    param(
        [Parameter(Mandatory)]
        [ValidateSet("GET", "POST", "PATCH", "DELETE")]
        [string]$Method,

        [Parameter(Mandatory)]
        [string]$Uri,

        [Parameter(Mandatory = $false)]
        $Body
    )

    try {
        if ($PSBoundParameters.ContainsKey("Body") -and $null -ne $Body) {
            $Json = ConvertTo-GraphJson -Body $Body

            if ($ShowJson -or $WhatIfOnly) {
                Write-Host ""
                Write-Host "JSON PAYLOAD: $Method $Uri" -ForegroundColor DarkCyan
                Write-Host $Json
            }

            if ($WhatIfOnly) {
                return $null
            }

            return Invoke-MgGraphRequest `
                -Method $Method `
                -Uri $Uri `
                -Body $Json `
                -ContentType "application/json"
        }

        if ($WhatIfOnly) {
            Write-Host "WHATIF: $Method $Uri" -ForegroundColor Magenta
            return $null
        }

        return Invoke-MgGraphRequest -Method $Method -Uri $Uri
    }
    catch {
        Write-Fail "$Method $Uri failed."
        Write-Host (Get-GraphErrorText -ErrorRecord $_) -ForegroundColor Red
        throw
    }
}

function Escape-ODataString {
    param([Parameter(Mandatory)][string]$Value)
    return $Value.Replace("'", "''")
}

function Escape-XmlText {
    param([Parameter(Mandatory)][string]$Value)

    return [System.Security.SecurityElement]::Escape($Value)
}

# -----------------------------
# macOS Custom Configuration helpers
# -----------------------------

function Get-DeviceConfigurationByDisplayName {
    param([Parameter(Mandatory)][string]$DisplayName)

    $EscapedName = Escape-ODataString -Value $DisplayName
    $Uri = "$GraphBaseUri/deviceManagement/deviceConfigurations?`$filter=displayName eq '$EscapedName'"

    $Response = Invoke-GraphJson -Method GET -Uri $Uri

    if ($Response -and $Response.value -and $Response.value.Count -gt 0) {
        return $Response.value[0]
    }

    return $null
}

function ConvertTo-Base64Utf8 {
    param([Parameter(Mandatory)][string]$Content)

    $Bytes = [System.Text.Encoding]::UTF8.GetBytes($Content)
    return [System.Convert]::ToBase64String($Bytes)
}

function New-MacOSCustomConfigurationBody {
    param(
        [Parameter(Mandatory)][string]$DisplayName,
        [Parameter(Mandatory)][string]$Description,
        [Parameter(Mandatory)][string]$PayloadName,
        [Parameter(Mandatory)][string]$PayloadFileName,
        [Parameter(Mandatory)][string]$PayloadContent
    )

    return @{
        "@odata.type" = "#microsoft.graph.macOSCustomConfiguration"
        displayName = $DisplayName
        description = $Description
        version = 1
        payloadName = $PayloadName
        payloadFileName = $PayloadFileName
        payload = (ConvertTo-Base64Utf8 -Content $PayloadContent)
    }
}

function New-OrUpdate-MacOSCustomConfiguration {
    param(
        [Parameter(Mandatory)]
        [hashtable]$PolicyBody
    )

    $DisplayName = [string]$PolicyBody.displayName

    Write-Info "Checking for existing macOS custom configuration: $DisplayName"
    $ExistingPolicy = Get-DeviceConfigurationByDisplayName -DisplayName $DisplayName

    if ($ExistingPolicy) {
        Write-Warn "Policy already exists: $DisplayName"
        Write-Info "Existing Policy ID: $($ExistingPolicy.id)"

        if ($UpdateExisting) {
            Write-Info "Updating existing policy because -UpdateExisting was supplied."

            $PatchBody = $PolicyBody.Clone()
            $PatchBody.Remove("@odata.type")

            Invoke-GraphJson `
                -Method PATCH `
                -Uri "$GraphBaseUri/deviceManagement/deviceConfigurations/$($ExistingPolicy.id)" `
                -Body $PatchBody | Out-Null

            Write-Success "Updated policy: $DisplayName"
        }
        else {
            Write-Info "Leaving existing policy unchanged. Use -UpdateExisting to patch it."
        }

        return $ExistingPolicy.id
    }

    Write-Info "Creating policy: $DisplayName"

    $CreatedPolicy = Invoke-GraphJson `
        -Method POST `
        -Uri "$GraphBaseUri/deviceManagement/deviceConfigurations" `
        -Body $PolicyBody

    if (-not $CreatedPolicy -or [string]::IsNullOrWhiteSpace($CreatedPolicy.id)) {
        Write-Warn "Policy ID is blank after creation attempt for $DisplayName."
        return $null
    }

    Write-Success "Created policy: $DisplayName"
    Write-Info "Policy ID: $($CreatedPolicy.id)"

    return $CreatedPolicy.id
}

function Set-DeviceConfigurationAssignment {
    param(
        [Parameter(Mandatory)][string]$PolicyId,
        [Parameter(Mandatory)][string]$GroupId
    )

    if ([string]::IsNullOrWhiteSpace($PolicyId)) {
        Write-Warn "Policy ID is blank. Skipping assignment."
        return
    }

    if ($NoAssignments) {
        Write-Warn "Skipping assignment because -NoAssignments was supplied."
        return
    }

    $AssignmentBody = @{
        assignments = @(
            @{
                "@odata.type" = "#microsoft.graph.deviceConfigurationAssignment"
                target = @{
                    "@odata.type" = "#microsoft.graph.groupAssignmentTarget"
                    groupId = $GroupId
                }
            }
        )
    }

    Write-Info "Assigning policy $PolicyId to group $GroupId"

    Invoke-GraphJson `
        -Method POST `
        -Uri "$GraphBaseUri/deviceManagement/deviceConfigurations/$PolicyId/assign" `
        -Body $AssignmentBody | Out-Null

    Write-Success "Assigned policy $PolicyId to group $GroupId"
}

# -----------------------------
# Payload builders
# -----------------------------

function New-MobileConfig {
    param(
        [Parameter(Mandatory)][string]$PayloadIdentifier,
        [Parameter(Mandatory)][string]$PayloadDisplayName,
        [Parameter(Mandatory)][string]$PayloadContentXml
    )

    $TopUuid = [guid]::NewGuid().Guid.ToUpper()

    return @"
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>PayloadContent</key>
    <array>
$PayloadContentXml
    </array>
    <key>PayloadDisplayName</key>
    <string>$PayloadDisplayName</string>
    <key>PayloadIdentifier</key>
    <string>$PayloadIdentifier</string>
    <key>PayloadOrganization</key>
    <string>Wave 2 Endpoint Security</string>
    <key>PayloadRemovalDisallowed</key>
    <true/>
    <key>PayloadScope</key>
    <string>System</string>
    <key>PayloadType</key>
    <string>Configuration</string>
    <key>PayloadUUID</key>
    <string>$TopUuid</string>
    <key>PayloadVersion</key>
    <integer>1</integer>
</dict>
</plist>
"@
}

function New-MacOSFirewallPayload {
    $InnerUuid = [guid]::NewGuid().Guid.ToUpper()

    $BlockIncoming = if ($BlockAllIncomingFirewallConnections) { "<true/>" } else { "<false/>" }

    $Inner = @"
        <dict>
            <key>PayloadDescription</key>
            <string>Enables the macOS application firewall and stealth mode.</string>
            <key>PayloadDisplayName</key>
            <string>macOS Firewall Baseline</string>
            <key>PayloadIdentifier</key>
            <string>com.atech.wave2.macos.firewall.payload</string>
            <key>PayloadOrganization</key>
            <string>Wave 2 Endpoint Security</string>
            <key>PayloadType</key>
            <string>com.apple.security.firewall</string>
            <key>PayloadUUID</key>
            <string>$InnerUuid</string>
            <key>PayloadVersion</key>
            <integer>1</integer>

            <key>EnableFirewall</key>
            <true/>

            <key>EnableStealthMode</key>
            <true/>

            <key>BlockAllIncoming</key>
            $BlockIncoming
        </dict>
"@

    return New-MobileConfig `
        -PayloadIdentifier "com.atech.wave2.macos.firewall" `
        -PayloadDisplayName "macOS Firewall Baseline" `
        -PayloadContentXml $Inner
}

function New-MacOSFileVaultPayload {
    $FileVaultPayloadUuid = [guid]::NewGuid().Guid.ToUpper()
    $McxPayloadUuid = [guid]::NewGuid().Guid.ToUpper()

    $EscrowText = Escape-XmlText -Value $EscrowLocation
    $ForceSetupAssistant = if ($DisableFileVaultAtSetupAssistant) { "<false/>" } else { "<true/>" }
    $PreventDisable = if ($AllowFileVaultDisable) { "<false/>" } else { "<true/>" }

    $Inner = @"
        <dict>
            <key>PayloadDescription</key>
            <string>Prevents users from disabling FileVault where supported.</string>
            <key>PayloadDisplayName</key>
            <string>FileVault Options</string>
            <key>PayloadIdentifier</key>
            <string>com.atech.wave2.macos.filevault.options.payload</string>
            <key>PayloadOrganization</key>
            <string>Wave 2 Endpoint Security</string>
            <key>PayloadType</key>
            <string>com.apple.MCX</string>
            <key>PayloadUUID</key>
            <string>$McxPayloadUuid</string>
            <key>PayloadVersion</key>
            <integer>1</integer>

            <key>dontAllowFDEDisable</key>
            $PreventDisable
        </dict>
        <dict>
            <key>PayloadDescription</key>
            <string>Enables FileVault using a personal recovery key.</string>
            <key>PayloadDisplayName</key>
            <string>FileVault Enforcement</string>
            <key>PayloadIdentifier</key>
            <string>com.atech.wave2.macos.filevault.payload</string>
            <key>PayloadOrganization</key>
            <string>Wave 2 Endpoint Security</string>
            <key>PayloadType</key>
            <string>com.apple.MCX.FileVault2</string>
            <key>PayloadUUID</key>
            <string>$FileVaultPayloadUuid</string>
            <key>PayloadVersion</key>
            <integer>1</integer>

            <key>Enable</key>
            <true/>

            <key>Defer</key>
            <true/>

            <key>ForceEnableInSetupAssistant</key>
            $ForceSetupAssistant

            <key>UseRecoveryKey</key>
            <true/>

            <key>ShowRecoveryKey</key>
            <false/>

            <key>DontAskAtUserLogout</key>
            <false/>

            <key>MaxBypassAttempts</key>
            <integer>$FileVaultBypassAttempts</integer>

            <key>Location</key>
            <string>$EscrowText</string>
        </dict>
"@

    return New-MobileConfig `
        -PayloadIdentifier "com.atech.wave2.macos.filevault" `
        -PayloadDisplayName "macOS FileVault Baseline" `
        -PayloadContentXml $Inner
}

# -----------------------------
# Main
# -----------------------------

Write-Section "Wave 2 macOS FileVault and Firewall Deployment"

Write-Info "Target group ID: $TargetGroupId"
Write-Info "Escrow location text: $EscrowLocation"
Write-Info "FileVault bypass attempts: $FileVaultBypassAttempts"
Write-Info "Force FileVault in Setup Assistant: $(-not $DisableFileVaultAtSetupAssistant.IsPresent)"
Write-Info "Allow FileVault disable: $($AllowFileVaultDisable.IsPresent)"
Write-Info "Block all incoming firewall connections: $($BlockAllIncomingFirewallConnections.IsPresent)"
Write-Info "Update existing policies: $($UpdateExisting.IsPresent)"
Write-Info "Skip assignments: $($NoAssignments.IsPresent)"
Write-Info "WhatIfOnly: $($WhatIfOnly.IsPresent)"

Write-Warn "FileVault recovery key escrow should be validated in Intune before broad rollout."
Write-Warn "For production escrow/rotation, prefer Intune Endpoint Security > Disk Encryption or Settings Catalog FileVault."

if (-not $WhatIfOnly) {
    Connect-ToGraph
}
else {
    Ensure-GraphAuthenticationModule
    Write-Warn "WHATIF mode enabled. No Graph changes will be made."
}

$CreatedPolicyIds = [ordered]@{}

$Profiles = @(
    @{
        DisplayName = "$PolicyNamePrefix-macOS-Firewall"
        Description = "Wave 2 macOS Firewall baseline. Enables firewall and stealth mode."
        PayloadName = "macOS Firewall Baseline"
        PayloadFileName = "W2-SEC-macOS-Firewall.mobileconfig"
        PayloadContent = (New-MacOSFirewallPayload)
    },
    @{
        DisplayName = "$PolicyNamePrefix-macOS-FileVault"
        Description = "Wave 2 macOS FileVault baseline. Enables FileVault with personal recovery key. Validate recovery key escrow before production."
        PayloadName = "macOS FileVault Baseline"
        PayloadFileName = "W2-SEC-macOS-FileVault.mobileconfig"
        PayloadContent = (New-MacOSFileVaultPayload)
    }
)

foreach ($Profile in $Profiles) {
    Write-Section $Profile.DisplayName

    try {
        $PolicyBody = New-MacOSCustomConfigurationBody `
            -DisplayName $Profile.DisplayName `
            -Description $Profile.Description `
            -PayloadName $Profile.PayloadName `
            -PayloadFileName $Profile.PayloadFileName `
            -PayloadContent $Profile.PayloadContent

        $PolicyId = New-OrUpdate-MacOSCustomConfiguration -PolicyBody $PolicyBody
        $CreatedPolicyIds[$Profile.DisplayName] = $PolicyId

        if ($PolicyId) {
            Set-DeviceConfigurationAssignment -PolicyId $PolicyId -GroupId $TargetGroupId
        }
    }
    catch {
        Write-Fail "Deployment failed for $($Profile.DisplayName)."
    }
}

Write-Section "Deployment summary"

foreach ($Policy in $CreatedPolicyIds.GetEnumerator()) {
    Write-Host "$($Policy.Key): $($Policy.Value)"
}

Write-Host ""
Write-Success "Wave 2 macOS FileVault and Firewall deployment complete."

Write-Host ""
Write-Info "Recommended validation on pilot Mac:"
Write-Host "  fdesetup status"
Write-Host "  /usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate"
Write-Host "  /usr/libexec/ApplicationFirewall/socketfilterfw --getstealthmode"
