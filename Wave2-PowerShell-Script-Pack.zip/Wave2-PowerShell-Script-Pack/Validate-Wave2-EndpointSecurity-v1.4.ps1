<#
.SYNOPSIS
    Validates Wave 2 Intune Endpoint Security deployment and exports reporting data.

.DESCRIPTION
    Read-only validation script for the Wave 2 baseline:

    Compliance policies:
      - W2-COMP-Windows-Baseline
      - W2-COMP-macOS-Baseline

    Windows endpoint security:
      - W2-SEC-Windows-Defender-AV
      - W2-SEC-Windows-ASR-Audit / Block / Warn / Disabled
      - W2-SEC-Windows-Firewall
      - W2-SEC-Windows-BitLocker

    macOS endpoint security:
      - W2-SEC-macOS-Defender-SystemExtensions
      - W2-SEC-macOS-Defender-NetworkFilter
      - W2-SEC-macOS-Defender-FullDiskAccess
      - W2-SEC-macOS-Defender-Preferences
      - W2-SEC-macOS-Defender-Onboarding
      - W2-SEC-macOS-Firewall
      - W2-SEC-macOS-FileVault

    The script exports:
      - Policy validation report
      - Policy/device status report
      - Device posture report
      - Summary report
      - Raw JSON snapshot

.REQUIREMENTS
    PowerShell 7 recommended.
    Microsoft.Graph.Authentication module.

.GRAPH PERMISSIONS
    DeviceManagementConfiguration.Read.All
    DeviceManagementManagedDevices.Read.All
    Directory.Read.All
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$TenantId,

    [Parameter(Mandatory = $false)]
    [ValidatePattern('^[0-9a-fA-F-]{36}$')]
    [Alias("PilotGroupId")]
    [string]$TargetGroupId,

    [Parameter(Mandatory = $false)]
    [string]$PolicyNamePrefixSecurity = "W2-SEC",

    [Parameter(Mandatory = $false)]
    [string]$PolicyNamePrefixCompliance = "W2-COMP",

    [Parameter(Mandatory = $false)]
    [string]$OutputFolder = ".\Wave2-Validation-Reports",

    [Parameter(Mandatory = $false)]
    [switch]$SkipDeviceReport,

    [Parameter(Mandatory = $false)]
    [switch]$SkipPolicyStatusDetails,

    [Parameter(Mandatory = $false)]
    [switch]$IncludeAllManagedDevices,

    [Parameter(Mandatory = $false)]
    [int]$StaleDeviceDays = 14,

    [Parameter(Mandatory = $false)]
    [switch]$ShowJson
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$GraphBaseUri = "https://graph.microsoft.com/v1.0"
$RunTimestamp = Get-Date -Format "yyyyMMdd-HHmmss"

function Write-Section {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host $Message -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
}
function Write-Info { param([Parameter(Mandatory)][string]$Message) Write-Host "[INFO] $Message" -ForegroundColor White }
function Write-Success { param([Parameter(Mandatory)][string]$Message) Write-Host "[OK]   $Message" -ForegroundColor Green }
function Write-Warn { param([Parameter(Mandatory)][string]$Message) Write-Host "[WARN] $Message" -ForegroundColor Yellow }
function Write-Fail { param([Parameter(Mandatory)][string]$Message) Write-Host "[FAIL] $Message" -ForegroundColor Red }

function Ensure-GraphAuthenticationModule {
    if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Authentication)) {
        Write-Warn "Microsoft.Graph.Authentication module is not installed."
        Write-Info "Installing Microsoft.Graph.Authentication for current user..."
        Install-Module Microsoft.Graph.Authentication -Scope CurrentUser -Force -AllowClobber
    }
    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
}

function Connect-ToGraph {
    Ensure-GraphAuthenticationModule

    $Scopes = @(
        "DeviceManagementConfiguration.Read.All",
        "DeviceManagementManagedDevices.Read.All",
        "Directory.Read.All"
    )

    $ExistingContext = Get-MgContext -ErrorAction SilentlyContinue

    if ($ExistingContext) {
        Write-Info "Existing Graph context detected for tenant $($ExistingContext.TenantId)."
        if ($TenantId -and ($ExistingContext.TenantId -ne $TenantId)) {
            Write-Warn "Connected tenant does not match requested tenant. Reconnecting..."
            Disconnect-MgGraph | Out-Null
            $ExistingContext = $null
        }
    }

    if (-not $ExistingContext) {
        if ($TenantId) {
            Write-Info "Connecting to Microsoft Graph tenant $TenantId..."
            Connect-MgGraph -TenantId $TenantId -Scopes $Scopes -NoWelcome | Out-Null
        }
        else {
            Write-Info "Connecting to Microsoft Graph..."
            Connect-MgGraph -Scopes $Scopes -NoWelcome | Out-Null
        }
    }

    $Context = Get-MgContext
    if (-not $Context) {
        throw "Could not establish Microsoft Graph context."
    }

    Write-Success "Connected to tenant $($Context.TenantId) as $($Context.Account)."
}

function Get-GraphErrorText {
    param([Parameter(Mandatory)]$ErrorRecord)
    if ($ErrorRecord.ErrorDetails -and $ErrorRecord.ErrorDetails.Message) {
        return $ErrorRecord.ErrorDetails.Message
    }
    return $ErrorRecord.Exception.Message
}

function Invoke-GraphGet {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [Parameter(Mandatory = $false)][switch]$AllPages
    )

    try {
        if ($ShowJson) {
            Write-Host "GET $Uri" -ForegroundColor DarkCyan
        }

        if (-not $AllPages) {
            return Invoke-MgGraphRequest -Method GET -Uri $Uri
        }

        $Results = @()
        $NextUri = $Uri

        while (-not [string]::IsNullOrWhiteSpace($NextUri)) {
            $Response = Invoke-MgGraphRequest -Method GET -Uri $NextUri

            if ($null -ne $Response -and ($Response.PSObject.Properties.Name -contains "value") -and $null -ne $Response.value) {
                $Results += @($Response.value)
            }

            if ($null -ne $Response -and ($Response.PSObject.Properties.Name -contains "@odata.nextLink")) {
                $NextUri = $Response.'@odata.nextLink'
            }
            else {
                $NextUri = $null
            }
        }

        return @{ value = @($Results) }
    }
    catch {
        Write-Fail "GET $Uri failed."
        Write-Host (Get-GraphErrorText -ErrorRecord $_) -ForegroundColor Red
        return @{ value = @() }
    }
}

function Get-ObjectPropertyValue {
    param(
        [Parameter(Mandatory = $false)]$Object,
        [Parameter(Mandatory)][string]$PropertyName
    )

    if ($null -eq $Object) {
        return $null
    }

    if ($Object.PSObject.Properties.Name -contains $PropertyName) {
        return $Object.$PropertyName
    }

    return $null
}

function Test-ObjectDisplayNameEquals {
    param(
        [Parameter(Mandatory = $false)]$Object,
        [Parameter(Mandatory)][string]$DisplayName
    )

    $Value = Get-ObjectPropertyValue -Object $Object -PropertyName "displayName"
    return ([string]$Value -eq [string]$DisplayName)
}

function Get-ExpectedPolicies {
    $AsrNames = @(
        "$PolicyNamePrefixSecurity-Windows-ASR-Audit",
        "$PolicyNamePrefixSecurity-Windows-ASR-Block",
        "$PolicyNamePrefixSecurity-Windows-ASR-Warn",
        "$PolicyNamePrefixSecurity-Windows-ASR-Disabled"
    )

    return @(
        [pscustomobject]@{ Area = "Compliance"; Platform = "Windows"; ExpectedName = "$PolicyNamePrefixCompliance-Windows-Baseline"; Type = "CompliancePolicy"; Required = $true },
        [pscustomobject]@{ Area = "Compliance"; Platform = "macOS"; ExpectedName = "$PolicyNamePrefixCompliance-macOS-Baseline"; Type = "CompliancePolicy"; Required = $true },
        [pscustomobject]@{ Area = "Endpoint Protection"; Platform = "Windows"; ExpectedName = "$PolicyNamePrefixSecurity-Windows-Defender-AV"; Type = "DeviceConfiguration"; Required = $true },
        [pscustomobject]@{ Area = "Endpoint Protection"; Platform = "Windows"; ExpectedName = ($AsrNames -join "|"); Type = "DeviceConfigurationAny"; Required = $true },
        [pscustomobject]@{ Area = "Endpoint Security"; Platform = "Windows"; ExpectedName = "$PolicyNamePrefixSecurity-Windows-Firewall"; Type = "DeviceConfiguration"; Required = $true },
        [pscustomobject]@{ Area = "Endpoint Security"; Platform = "Windows"; ExpectedName = "$PolicyNamePrefixSecurity-Windows-BitLocker"; Type = "DeviceConfiguration"; Required = $true },
        [pscustomobject]@{ Area = "Endpoint Protection"; Platform = "macOS"; ExpectedName = "$PolicyNamePrefixSecurity-macOS-Defender-SystemExtensions"; Type = "DeviceConfiguration"; Required = $true },
        [pscustomobject]@{ Area = "Endpoint Protection"; Platform = "macOS"; ExpectedName = "$PolicyNamePrefixSecurity-macOS-Defender-NetworkFilter"; Type = "DeviceConfiguration"; Required = $true },
        [pscustomobject]@{ Area = "Endpoint Protection"; Platform = "macOS"; ExpectedName = "$PolicyNamePrefixSecurity-macOS-Defender-FullDiskAccess"; Type = "DeviceConfiguration"; Required = $true },
        [pscustomobject]@{ Area = "Endpoint Protection"; Platform = "macOS"; ExpectedName = "$PolicyNamePrefixSecurity-macOS-Defender-Preferences"; Type = "DeviceConfiguration"; Required = $true },
        [pscustomobject]@{ Area = "Endpoint Protection"; Platform = "macOS"; ExpectedName = "$PolicyNamePrefixSecurity-macOS-Defender-Onboarding"; Type = "DeviceConfiguration"; Required = $true },
        [pscustomobject]@{ Area = "Endpoint Security"; Platform = "macOS"; ExpectedName = "$PolicyNamePrefixSecurity-macOS-Firewall"; Type = "DeviceConfiguration"; Required = $true },
        [pscustomobject]@{ Area = "Endpoint Security"; Platform = "macOS"; ExpectedName = "$PolicyNamePrefixSecurity-macOS-FileVault"; Type = "DeviceConfiguration"; Required = $true }
    )
}

function Get-CompliancePolicies {
    $Response = Invoke-GraphGet -Uri "$GraphBaseUri/deviceManagement/deviceCompliancePolicies" -AllPages
    if ($Response -and ($Response.PSObject.Properties.Name -contains "value") -and $null -ne $Response.value) { return @($Response.value) }
    return @()
}

function Get-DeviceConfigurations {
    $Response = Invoke-GraphGet -Uri "$GraphBaseUri/deviceManagement/deviceConfigurations" -AllPages
    if ($Response -and ($Response.PSObject.Properties.Name -contains "value") -and $null -ne $Response.value) { return @($Response.value) }
    return @()
}

function Get-AssignmentsForPolicy {
    param(
        [Parameter(Mandatory)][string]$PolicyId,
        [Parameter(Mandatory)][ValidateSet("CompliancePolicy", "DeviceConfiguration")][string]$Type
    )

    if ($Type -eq "CompliancePolicy") {
        $Uri = "$GraphBaseUri/deviceManagement/deviceCompliancePolicies/$PolicyId/assignments"
    }
    else {
        $Uri = "$GraphBaseUri/deviceManagement/deviceConfigurations/$PolicyId/assignments"
    }

    $Response = Invoke-GraphGet -Uri $Uri -AllPages
    if ($Response -and ($Response.PSObject.Properties.Name -contains "value") -and $null -ne $Response.value) { return @($Response.value) }
    return @()
}

function Get-DeviceStatusesForPolicy {
    param(
        [Parameter(Mandatory)][string]$PolicyId,
        [Parameter(Mandatory)][ValidateSet("CompliancePolicy", "DeviceConfiguration")][string]$Type
    )

    if ($SkipPolicyStatusDetails) { return @() }

    if ($Type -eq "CompliancePolicy") {
        $Uri = "$GraphBaseUri/deviceManagement/deviceCompliancePolicies/$PolicyId/deviceStatuses"
    }
    else {
        $Uri = "$GraphBaseUri/deviceManagement/deviceConfigurations/$PolicyId/deviceStatuses"
    }

    $Response = Invoke-GraphGet -Uri $Uri -AllPages
    if ($Response -and ($Response.PSObject.Properties.Name -contains "value") -and $null -ne $Response.value) { return @($Response.value) }
    return @()
}

function Test-AssignedToTargetGroup {
    param([array]$Assignments)
    if (-not $TargetGroupId) { return $null }

    foreach ($Assignment in $Assignments) {
        try {
            if ($Assignment.target.groupId -eq $TargetGroupId) { return $true }
        }
        catch {}
    }
    return $false
}

function Get-AssignmentTargetSummary {
    param([array]$Assignments)
    if (-not $Assignments -or $Assignments.Count -eq 0) { return "None" }

    $Targets = foreach ($Assignment in $Assignments) {
        try {
            $TargetType = $Assignment.target.'@odata.type'
            $GroupId = $Assignment.target.groupId
            if ($GroupId) { "${TargetType}:$GroupId" } else { "$TargetType" }
        }
        catch { "UnknownTarget" }
    }

    return ($Targets -join "; ")
}

function New-PolicyValidationRows {
    param(
        [array]$ExpectedPolicies,
        [array]$CompliancePolicies,
        [array]$DeviceConfigurations
    )

    $Rows = @()
    $RawPolicyStatusRows = @()

    foreach ($Expected in $ExpectedPolicies) {
        $MatchedPolicies = @()
        $LookupType = ""

        if ($Expected.Type -eq "CompliancePolicy") {
            $MatchedPolicies = @($CompliancePolicies | Where-Object { $null -ne $_ } | Where-Object { Test-ObjectDisplayNameEquals -Object $_ -DisplayName $Expected.ExpectedName })
            $LookupType = "CompliancePolicy"
        }
        elseif ($Expected.Type -eq "DeviceConfiguration") {
            $MatchedPolicies = @($DeviceConfigurations | Where-Object { $null -ne $_ } | Where-Object { Test-ObjectDisplayNameEquals -Object $_ -DisplayName $Expected.ExpectedName })
            $LookupType = "DeviceConfiguration"
        }
        elseif ($Expected.Type -eq "DeviceConfigurationAny") {
            $AllowedNames = $Expected.ExpectedName -split "\|"
            $MatchedPolicies = @($DeviceConfigurations | Where-Object { $null -ne $_ } | Where-Object { $AllowedNames -contains (Get-ObjectPropertyValue -Object $_ -PropertyName "displayName") })
            $LookupType = "DeviceConfiguration"
        }

        if (-not $MatchedPolicies -or $MatchedPolicies.Count -eq 0) {
            $Rows += [pscustomobject]@{
                Area = $Expected.Area; Platform = $Expected.Platform; ExpectedName = $Expected.ExpectedName
                MatchedName = ""; PolicyType = $Expected.Type; PolicyId = ""; Exists = $false
                AssignmentCount = 0; AssignedToTargetGroup = if ($TargetGroupId) { $false } else { $null }
                AssignmentTargets = ""; DeviceStatusSuccess = 0; DeviceStatusError = 0
                DeviceStatusConflict = 0; DeviceStatusUnknown = 0; LastModifiedDateTime = ""; Result = "Missing"
            }
            continue
        }

        foreach ($Policy in $MatchedPolicies) {
            $Assignments = Get-AssignmentsForPolicy -PolicyId $Policy.id -Type $LookupType
            $AssignedToTarget = Test-AssignedToTargetGroup -Assignments $Assignments
            $TargetSummary = Get-AssignmentTargetSummary -Assignments $Assignments
            $Statuses = Get-DeviceStatusesForPolicy -PolicyId $Policy.id -Type $LookupType

            $SuccessCount = @($Statuses | Where-Object { $_.status -match "success|compliant" }).Count
            $ErrorCount = @($Statuses | Where-Object { $_.status -match "error|nonCompliant|failed" }).Count
            $ConflictCount = @($Statuses | Where-Object { $_.status -match "conflict" }).Count
            $UnknownCount = @($Statuses | Where-Object { $_.status -match "unknown|notApplicable|pending" }).Count

            foreach ($Status in $Statuses) {
                $RawPolicyStatusRows += [pscustomobject]@{
                    PolicyName = (Get-ObjectPropertyValue -Object $Policy -PropertyName "displayName")
                    PolicyId = $Policy.id
                    PolicyType = $LookupType
                    DeviceDisplayName = $Status.deviceDisplayName
                    UserName = $Status.userName
                    Status = $Status.status
                    LastReportedDateTime = $Status.lastReportedDateTime
                    ComplianceGracePeriodExpirationDateTime = $Status.complianceGracePeriodExpirationDateTime
                }
            }

            $Result = "OK"
            if ($TargetGroupId -and -not $AssignedToTarget) { $Result = "Exists but not assigned to target group" }
            if ($ErrorCount -gt 0) { $Result = "Policy has device errors" }

            $Rows += [pscustomobject]@{
                Area = $Expected.Area; Platform = $Expected.Platform; ExpectedName = $Expected.ExpectedName
                MatchedName = (Get-ObjectPropertyValue -Object $Policy -PropertyName "displayName"); PolicyType = $LookupType; PolicyId = $Policy.id; Exists = $true
                AssignmentCount = $Assignments.Count; AssignedToTargetGroup = $AssignedToTarget
                AssignmentTargets = $TargetSummary; DeviceStatusSuccess = $SuccessCount; DeviceStatusError = $ErrorCount
                DeviceStatusConflict = $ConflictCount; DeviceStatusUnknown = $UnknownCount
                LastModifiedDateTime = (Get-ObjectPropertyValue -Object $Policy -PropertyName "lastModifiedDateTime"); Result = $Result
            }
        }
    }

    return @{ PolicyRows = $Rows; RawPolicyStatusRows = $RawPolicyStatusRows }
}

function Get-ManagedDevices {
    $Select = "id,deviceName,managedDeviceName,userPrincipalName,operatingSystem,osVersion,complianceState,managementAgent,managementState,azureADDeviceId,serialNumber,model,manufacturer,lastSyncDateTime,enrolledDateTime,deviceEnrollmentType,isEncrypted,isSupervised,jailBroken,partnerReportedThreatState"
    $Response = Invoke-GraphGet -Uri "$GraphBaseUri/deviceManagement/managedDevices?`$select=$Select" -AllPages
    if ($Response -and ($Response.PSObject.Properties.Name -contains "value") -and $null -ne $Response.value) { return @($Response.value) }
    return @()
}

function Get-DeviceRiskLabel {
    param($Device)
    try {
        if ($Device.partnerReportedThreatState) { return [string]$Device.partnerReportedThreatState }
    }
    catch {}
    return "unknown"
}

function Get-DeviceIssues {
    param($Device)
    $Issues = @()

    if ($Device.complianceState -and $Device.complianceState -ne "compliant") {
        $Issues += "Compliance=$($Device.complianceState)"
    }

    try {
        if ($null -ne $Device.isEncrypted -and $Device.isEncrypted -eq $false) { $Issues += "Encryption not reported enabled" }
    }
    catch {}

    try {
        if ($Device.jailBroken -and $Device.jailBroken -notin @("False", "false", "Unknown", "unknown")) {
            $Issues += "Jailbreak/root state=$($Device.jailBroken)"
        }
    }
    catch {}

    $Risk = Get-DeviceRiskLabel -Device $Device
    if ($Risk -and $Risk -notin @("unknown", "notActivated", "none", "clean")) {
        $Issues += "ThreatState=$Risk"
    }

    if ($Device.lastSyncDateTime) {
        try {
            $LastSync = [datetime]$Device.lastSyncDateTime
            if ($LastSync -lt (Get-Date).AddDays(-$StaleDeviceDays)) { $Issues += "Stale sync > $StaleDeviceDays days" }
        }
        catch {}
    }

    if ($Issues.Count -eq 0) { return "None" }
    return ($Issues -join "; ")
}

function New-DevicePostureRows {
    param([array]$ManagedDevices)

    $Rows = @()
    foreach ($Device in $ManagedDevices) {
        $Os = [string]$Device.operatingSystem
        if (-not $IncludeAllManagedDevices -and $Os -notmatch "Windows|macOS|Mac") { continue }

        $Rows += [pscustomobject]@{
            DeviceName = if ($Device.deviceName) { $Device.deviceName } else { $Device.managedDeviceName }
            ManagedDeviceId = $Device.id
            AzureADDeviceId = $Device.azureADDeviceId
            UserPrincipalName = $Device.userPrincipalName
            OperatingSystem = $Device.operatingSystem
            OSVersion = $Device.osVersion
            Manufacturer = $Device.manufacturer
            Model = $Device.model
            SerialNumber = $Device.serialNumber
            ComplianceState = $Device.complianceState
            IsEncrypted = $Device.isEncrypted
            PartnerReportedThreatState = Get-DeviceRiskLabel -Device $Device
            ManagementAgent = $Device.managementAgent
            ManagementState = $Device.managementState
            EnrollmentType = $Device.deviceEnrollmentType
            IsSupervised = $Device.isSupervised
            JailBroken = $Device.jailBroken
            LastSyncDateTime = $Device.lastSyncDateTime
            EnrolledDateTime = $Device.enrolledDateTime
            Issues = Get-DeviceIssues -Device $Device
        }
    }
    return $Rows
}

function New-SummaryRows {
    param([array]$PolicyRows, [array]$DeviceRows)

    $Summary = @()
    $Summary += [pscustomobject]@{ Metric = "Expected policies"; Value = $PolicyRows.Count }
    $Summary += [pscustomobject]@{ Metric = "Policies found"; Value = @($PolicyRows | Where-Object { $_.Exists -eq $true }).Count }
    $Summary += [pscustomobject]@{ Metric = "Policies missing"; Value = @($PolicyRows | Where-Object { $_.Exists -eq $false }).Count }
    $Summary += [pscustomobject]@{ Metric = "Policies assigned to target group"; Value = @($PolicyRows | Where-Object { $_.AssignedToTargetGroup -eq $true }).Count }
    $Summary += [pscustomobject]@{ Metric = "Policies with device errors"; Value = @($PolicyRows | Where-Object { $_.DeviceStatusError -gt 0 }).Count }

    if ($DeviceRows) {
        $Summary += [pscustomobject]@{ Metric = "Managed devices in report"; Value = $DeviceRows.Count }
        $Summary += [pscustomobject]@{ Metric = "Compliant devices"; Value = @($DeviceRows | Where-Object { $_.ComplianceState -eq "compliant" }).Count }
        $Summary += [pscustomobject]@{ Metric = "Non-compliant devices"; Value = @($DeviceRows | Where-Object { $_.ComplianceState -ne "compliant" }).Count }
        $Summary += [pscustomobject]@{ Metric = "Encrypted devices"; Value = @($DeviceRows | Where-Object { $_.IsEncrypted -eq $true }).Count }
        $Summary += [pscustomobject]@{ Metric = "Devices with issues"; Value = @($DeviceRows | Where-Object { $_.Issues -ne "None" }).Count }
        $Summary += [pscustomobject]@{ Metric = "Windows devices"; Value = @($DeviceRows | Where-Object { $_.OperatingSystem -match "Windows" }).Count }
        $Summary += [pscustomobject]@{ Metric = "macOS devices"; Value = @($DeviceRows | Where-Object { $_.OperatingSystem -match "macOS|Mac" }).Count }
    }

    return $Summary
}

Write-Section "Wave 2 Endpoint Security Validation"
Write-Info "Output folder: $OutputFolder"
Write-Info "Target group ID: $TargetGroupId"
Write-Info "Skip device report: $($SkipDeviceReport.IsPresent)"
Write-Info "Skip policy status details: $($SkipPolicyStatusDetails.IsPresent)"
Write-Info "Include all managed devices: $($IncludeAllManagedDevices.IsPresent)"

Connect-ToGraph

if (-not (Test-Path $OutputFolder)) {
    New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
}

Write-Section "Collecting policies"
$ExpectedPolicies = Get-ExpectedPolicies
$CompliancePolicies = Get-CompliancePolicies
$DeviceConfigurations = Get-DeviceConfigurations
Write-Info "Compliance policies returned: $(@($CompliancePolicies).Count)"
Write-Info "Device configurations returned: $(@($DeviceConfigurations).Count)"

Write-Section "Validating policy existence, assignments and status"
$PolicyValidation = New-PolicyValidationRows -ExpectedPolicies $ExpectedPolicies -CompliancePolicies $CompliancePolicies -DeviceConfigurations $DeviceConfigurations
$PolicyRows = @($PolicyValidation.PolicyRows)
$RawPolicyStatusRows = @($PolicyValidation.RawPolicyStatusRows)

$DeviceRows = @()
if (-not $SkipDeviceReport) {
    Write-Section "Collecting managed device posture"
    $ManagedDevices = Get-ManagedDevices
    Write-Info "Managed devices returned: $(@($ManagedDevices).Count)"
    $DeviceRows = @(New-DevicePostureRows -ManagedDevices $ManagedDevices)
}
else {
    Write-Warn "Device report skipped."
}

$SummaryRows = @(New-SummaryRows -PolicyRows $PolicyRows -DeviceRows $DeviceRows)

Write-Section "Exporting reports"
$PolicyCsv = Join-Path $OutputFolder "Wave2-PolicyValidation-$RunTimestamp.csv"
$PolicyStatusCsv = Join-Path $OutputFolder "Wave2-PolicyDeviceStatus-$RunTimestamp.csv"
$DeviceCsv = Join-Path $OutputFolder "Wave2-DevicePosture-$RunTimestamp.csv"
$SummaryCsv = Join-Path $OutputFolder "Wave2-Summary-$RunTimestamp.csv"
$RawJson = Join-Path $OutputFolder "Wave2-RawSnapshot-$RunTimestamp.json"

$PolicyRows | Export-Csv -Path $PolicyCsv -NoTypeInformation -Encoding UTF8
$SummaryRows | Export-Csv -Path $SummaryCsv -NoTypeInformation -Encoding UTF8
if ($RawPolicyStatusRows.Count -gt 0) { $RawPolicyStatusRows | Export-Csv -Path $PolicyStatusCsv -NoTypeInformation -Encoding UTF8 }
if ($DeviceRows.Count -gt 0) { $DeviceRows | Export-Csv -Path $DeviceCsv -NoTypeInformation -Encoding UTF8 }

$Snapshot = [ordered]@{
    RunTimestamp = $RunTimestamp
    TenantId = (Get-MgContext).TenantId
    TargetGroupId = $TargetGroupId
    ExpectedPolicies = $ExpectedPolicies
    PolicyValidation = $PolicyRows
    PolicyDeviceStatuses = $RawPolicyStatusRows
    DevicePosture = $DeviceRows
    Summary = $SummaryRows
}
$Snapshot | ConvertTo-Json -Depth 80 | Out-File -FilePath $RawJson -Encoding UTF8

Write-Success "Policy validation report: $PolicyCsv"
if ($RawPolicyStatusRows.Count -gt 0) { Write-Success "Policy device status report: $PolicyStatusCsv" }
if ($DeviceRows.Count -gt 0) { Write-Success "Device posture report: $DeviceCsv" }
Write-Success "Summary report: $SummaryCsv"
Write-Success "Raw JSON snapshot: $RawJson"

Write-Section "Console summary"
$SummaryRows | Format-Table -AutoSize

$MissingPolicies = @($PolicyRows | Where-Object { $_.Exists -eq $false })
$UnassignedPolicies = @($PolicyRows | Where-Object { $TargetGroupId -and $_.Exists -eq $true -and $_.AssignedToTargetGroup -eq $false })
$DeviceIssues = @($DeviceRows | Where-Object { $_.Issues -ne "None" })

if ($MissingPolicies.Count -gt 0) {
    Write-Warn "Missing policies detected:"
    $MissingPolicies | Select-Object Area, Platform, ExpectedName | Format-Table -AutoSize
}
if ($UnassignedPolicies.Count -gt 0) {
    Write-Warn "Policies not assigned to target group:"
    $UnassignedPolicies | Select-Object Platform, MatchedName, PolicyId | Format-Table -AutoSize
}
if ($DeviceIssues.Count -gt 0) {
    Write-Warn "Devices with issues detected. See device posture CSV for details."
}
if ($MissingPolicies.Count -eq 0 -and $UnassignedPolicies.Count -eq 0) {
    Write-Success "Wave 2 policy presence and target group assignment look good."
}

Write-Host ""
Write-Success "Wave 2 validation complete."
