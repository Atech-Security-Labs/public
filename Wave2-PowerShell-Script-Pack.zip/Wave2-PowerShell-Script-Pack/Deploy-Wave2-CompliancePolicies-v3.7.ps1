<#
.SYNOPSIS
    Deploys Wave 2 Intune compliance policies for Windows and macOS.

.DESCRIPTION
    v3.7 fixes the scheduledActionsForRule issue by preserving the required single-item array.
    PowerShell functions unwrap single-item arrays unless returned using the unary comma.

    Graph must receive:
      "scheduledActionsForRule": [
        {
          "ruleName": "PasswordRequired",
          "scheduledActionConfigurations": [
            {
              "actionType": "block",
              "gracePeriodHours": 0,
              "notificationTemplateId": ""
            }
          ]
        }
      ]

    Not:
      "scheduledActionsForRule": { ... }

.NOTES
    Windows MAA / Device Health Attestation settings are intentionally excluded:
      - requireHealthyDeviceReport
      - earlyLaunchAntiMalwareDriverEnabled
      - bitLockerEnabled
      - secureBootEnabled
      - codeIntegrityEnabled
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$TenantId,

    [Parameter(Mandatory = $true)]
    [Alias("PilotGroupId")]
    [ValidatePattern('^[0-9a-fA-F-]{36}$')]
    [string]$TargetGroupId,

    [Parameter(Mandatory = $false)]
    [string]$PolicyNamePrefix = "W2-COMP",

    [Parameter(Mandatory = $false)]
    [switch]$DisableDefenderRiskCheck,

    [Parameter(Mandatory = $false)]
    [switch]$UpdateExisting,

    [Parameter(Mandatory = $false)]
    [switch]$SkipWindows,

    [Parameter(Mandatory = $false)]
    [switch]$SkipMacOS,

    [Parameter(Mandatory = $false)]
    [switch]$NoAssignments,

    [Parameter(Mandatory = $false)]
    [switch]$WhatIfOnly,

    [Parameter(Mandatory = $false)]
    [switch]$ShowJson
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$GraphBaseUri = "https://graph.microsoft.com/v1.0"

function Write-Section {
    param([string]$Message)
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host $Message -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
}

function Write-Info { param([string]$Message) Write-Host "[INFO] $Message" -ForegroundColor White }
function Write-Success { param([string]$Message) Write-Host "[OK]   $Message" -ForegroundColor Green }
function Write-Warn { param([string]$Message) Write-Host "[WARN] $Message" -ForegroundColor Yellow }
function Write-Fail { param([string]$Message) Write-Host "[FAIL] $Message" -ForegroundColor Red }

function Ensure-GraphAuthenticationModule {
    if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Authentication)) {
        Write-Warn "Microsoft.Graph.Authentication module is not installed. Installing for current user..."
        Install-Module Microsoft.Graph.Authentication -Scope CurrentUser -Force -AllowClobber
    }

    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
}

function Connect-ToGraph {
    Ensure-GraphAuthenticationModule

    $Scopes = @(
        "DeviceManagementConfiguration.ReadWrite.All",
        "Directory.Read.All"
    )

    $ExistingContext = Get-MgContext -ErrorAction SilentlyContinue

    if ($ExistingContext -and $TenantId -and ($ExistingContext.TenantId -ne $TenantId)) {
        Write-Warn "Existing Graph tenant $($ExistingContext.TenantId) does not match requested tenant $TenantId. Reconnecting..."
        Disconnect-MgGraph | Out-Null
        $ExistingContext = $null
    }

    if (-not $ExistingContext) {
        if ($TenantId) {
            Connect-MgGraph -TenantId $TenantId -Scopes $Scopes -NoWelcome | Out-Null
        }
        else {
            Connect-MgGraph -Scopes $Scopes -NoWelcome | Out-Null
        }
    }

    $Context = Get-MgContext
    if (-not $Context) {
        throw "Could not establish Microsoft Graph context."
    }

    Write-Success "Connected to tenant $($Context.TenantId) as $($Context.Account)."
}

function ConvertTo-GraphJson {
    param([Parameter(Mandatory)]$Body)
    return ($Body | ConvertTo-Json -Depth 30)
}

function Get-GraphErrorText {
    param([Parameter(Mandatory)]$ErrorRecord)

    if ($ErrorRecord.ErrorDetails -and $ErrorRecord.ErrorDetails.Message) {
        return $ErrorRecord.ErrorDetails.Message
    }

    return $ErrorRecord.Exception.Message
}

function Invoke-GraphJson {
    param(
        [Parameter(Mandatory)]
        [ValidateSet("GET", "POST", "PATCH", "DELETE")]
        [string]$Method,

        [Parameter(Mandatory)]
        [string]$Uri,

        [Parameter(Mandatory = $false)]
        $Body
    )

    try {
        if ($PSBoundParameters.ContainsKey("Body") -and $null -ne $Body) {
            $Json = ConvertTo-GraphJson -Body $Body

            if ($ShowJson -or $WhatIfOnly) {
                Write-Host ""
                Write-Host "JSON PAYLOAD: $Method $Uri" -ForegroundColor DarkCyan
                Write-Host $Json
            }

            if ($WhatIfOnly) {
                return $null
            }

            return Invoke-MgGraphRequest `
                -Method $Method `
                -Uri $Uri `
                -Body $Json `
                -ContentType "application/json"
        }

        if ($WhatIfOnly) {
            Write-Host "WHATIF: $Method $Uri" -ForegroundColor Magenta
            return $null
        }

        return Invoke-MgGraphRequest -Method $Method -Uri $Uri
    }
    catch {
        Write-Fail "$Method $Uri failed."
        Write-Host (Get-GraphErrorText -ErrorRecord $_) -ForegroundColor Red
        throw
    }
}

function Escape-ODataString {
    param([Parameter(Mandatory)][string]$Value)
    return $Value.Replace("'", "''")
}

function Get-CompliancePolicyByDisplayName {
    param([Parameter(Mandatory)][string]$DisplayName)

    $EscapedName = Escape-ODataString -Value $DisplayName
    $Uri = "$GraphBaseUri/deviceManagement/deviceCompliancePolicies?`$filter=displayName eq '$EscapedName'"
    $Response = Invoke-GraphJson -Method GET -Uri $Uri

    if ($Response -and $Response.value -and $Response.value.Count -gt 0) {
        return $Response.value[0]
    }

    return $null
}

function New-DefaultScheduledActions {
    $ScheduledActionConfigurations = @(
        @{
            actionType = "block"
            gracePeriodHours = 0
            notificationTemplateId = ""
        }
    )

    $ScheduledActions = @(
        @{
            ruleName = "PasswordRequired"
            scheduledActionConfigurations = $ScheduledActionConfigurations
        }
    )

    # Critical: preserve the single-item array when returning from a PowerShell function.
    return ,$ScheduledActions
}

function Assert-ScheduledActionsShape {
    param([Parameter(Mandatory)][hashtable]$PolicyBody)

    if (-not $PolicyBody.ContainsKey("scheduledActionsForRule")) {
        throw "scheduledActionsForRule is missing."
    }

    if (-not ($PolicyBody.scheduledActionsForRule -is [array])) {
        throw "scheduledActionsForRule is not an array. PowerShell unwrapped the single-item array."
    }

    if ($PolicyBody.scheduledActionsForRule.Count -ne 1) {
        throw "scheduledActionsForRule must contain one rule. Found $($PolicyBody.scheduledActionsForRule.Count)."
    }

    $Rule = $PolicyBody.scheduledActionsForRule[0]

    if (-not ($Rule.scheduledActionConfigurations -is [array])) {
        throw "scheduledActionConfigurations is not an array."
    }

    $BlockActions = @($Rule.scheduledActionConfigurations | Where-Object { $_.actionType -eq "block" })

    if ($BlockActions.Count -ne 1) {
        throw "scheduledActionConfigurations must contain exactly one block action. Found $($BlockActions.Count)."
    }
}

function New-WindowsCompliancePolicyBody {
    $Body = @{
        "@odata.type" = "#microsoft.graph.windows10CompliancePolicy"
        displayName = "$PolicyNamePrefix-Windows-Baseline"
        description = "Wave 2 Windows compliance baseline. Created by Deploy-Wave2-CompliancePolicies-v3.7.ps1. MAA/DHA settings intentionally excluded."
        version = 1

        passwordRequired = $true
        passwordBlockSimple = $true
        passwordRequiredToUnlockFromIdle = $true
        passwordMinutesOfInactivityBeforeLock = 15
        passwordExpirationDays = 0
        passwordMinimumLength = 8
        passwordMinimumCharacterSetCount = 3
        passwordRequiredType = "alphanumeric"
        passwordPreviousPasswordBlockCount = 5

        storageRequireEncryption = $true
        activeFirewallRequired = $true
        defenderEnabled = $true
        rtpEnabled = $true
        antivirusRequired = $true
        antiSpywareRequired = $true

        scheduledActionsForRule = (New-DefaultScheduledActions)
    }

    if (-not $DisableDefenderRiskCheck) {
        $Body.deviceThreatProtectionEnabled = $true
        $Body.deviceThreatProtectionRequiredSecurityLevel = "medium"
    }

    return $Body
}

function New-MacOSCompliancePolicyBody {
    $Body = @{
        "@odata.type" = "#microsoft.graph.macOSCompliancePolicy"
        displayName = "$PolicyNamePrefix-macOS-Baseline"
        description = "Wave 2 macOS compliance baseline. Created by Deploy-Wave2-CompliancePolicies-v3.7.ps1."
        version = 1

        passwordRequired = $true
        passwordBlockSimple = $true
        passwordExpirationDays = 0
        passwordMinimumLength = 8
        passwordMinutesOfInactivityBeforeLock = 15
        passwordPreviousPasswordBlockCount = 5
        passwordMinimumCharacterSetCount = 3
        passwordRequiredType = "alphanumeric"

        systemIntegrityProtectionEnabled = $true
        storageRequireEncryption = $true
        firewallEnabled = $true
        firewallBlockAllIncoming = $false
        firewallEnableStealthMode = $true

        scheduledActionsForRule = (New-DefaultScheduledActions)
    }

    if (-not $DisableDefenderRiskCheck) {
        $Body.deviceThreatProtectionEnabled = $true
        $Body.deviceThreatProtectionRequiredSecurityLevel = "medium"
    }

    return $Body
}

function New-OrUpdate-CompliancePolicy {
    param([Parameter(Mandatory)][hashtable]$PolicyBody)

    $DisplayName = [string]$PolicyBody.displayName
    Write-Info "Checking for existing policy: $DisplayName"

    $ExistingPolicy = Get-CompliancePolicyByDisplayName -DisplayName $DisplayName

    if ($ExistingPolicy) {
        Write-Warn "Policy already exists: $DisplayName"
        Write-Info "Existing Policy ID: $($ExistingPolicy.id)"

        if ($UpdateExisting) {
            Write-Info "Updating existing policy because -UpdateExisting was supplied."

            $PatchBody = $PolicyBody.Clone()
            $PatchBody.Remove("@odata.type")
            $PatchBody.Remove("scheduledActionsForRule")

            Invoke-GraphJson `
                -Method PATCH `
                -Uri "$GraphBaseUri/deviceManagement/deviceCompliancePolicies/$($ExistingPolicy.id)" `
                -Body $PatchBody | Out-Null

            Write-Success "Updated policy: $DisplayName"
        }

        return $ExistingPolicy.id
    }

    Write-Info "Creating policy: $DisplayName"

    $CreatedPolicy = Invoke-GraphJson `
        -Method POST `
        -Uri "$GraphBaseUri/deviceManagement/deviceCompliancePolicies" `
        -Body $PolicyBody

    if (-not $CreatedPolicy -or [string]::IsNullOrWhiteSpace($CreatedPolicy.id)) {
        Write-Warn "Policy ID is blank after creation attempt for $DisplayName."
        return $null
    }

    Write-Success "Created policy: $DisplayName"
    Write-Info "Policy ID: $($CreatedPolicy.id)"

    return $CreatedPolicy.id
}

function Set-CompliancePolicyAssignment {
    param(
        [Parameter(Mandatory)][string]$PolicyId,
        [Parameter(Mandatory)][string]$GroupId
    )

    if ([string]::IsNullOrWhiteSpace($PolicyId)) {
        Write-Warn "Policy ID is blank. Skipping assignment."
        return
    }

    if ($NoAssignments) {
        Write-Warn "Skipping assignment because -NoAssignments was supplied."
        return
    }

    $AssignmentBody = @{
        assignments = @(
            @{
                "@odata.type" = "#microsoft.graph.deviceCompliancePolicyAssignment"
                target = @{
                    "@odata.type" = "#microsoft.graph.groupAssignmentTarget"
                    groupId = $GroupId
                }
            }
        )
    }

    Write-Info "Assigning policy $PolicyId to group $GroupId"

    Invoke-GraphJson `
        -Method POST `
        -Uri "$GraphBaseUri/deviceManagement/deviceCompliancePolicies/$PolicyId/assign" `
        -Body $AssignmentBody | Out-Null

    Write-Success "Assigned policy $PolicyId to group $GroupId"
}

Write-Section "Wave 2 Intune Compliance Policy Deployment"

Write-Info "Target group ID: $TargetGroupId"
Write-Info "Disable Defender risk check: $($DisableDefenderRiskCheck.IsPresent)"

if (-not $WhatIfOnly) {
    Connect-ToGraph
}
else {
    Ensure-GraphAuthenticationModule
    Write-Warn "WHATIF mode enabled. No Graph changes will be made."
}

$WindowsPolicyId = $null
$MacOSPolicyId = $null

if (-not $SkipWindows) {
    Write-Section "Windows compliance policy"

    try {
        $WindowsPolicyBody = New-WindowsCompliancePolicyBody
        Assert-ScheduledActionsShape -PolicyBody $WindowsPolicyBody
        $WindowsPolicyId = New-OrUpdate-CompliancePolicy -PolicyBody $WindowsPolicyBody

        if ($WindowsPolicyId) {
            Set-CompliancePolicyAssignment -PolicyId $WindowsPolicyId -GroupId $TargetGroupId
        }
    }
    catch {
        Write-Fail "Windows compliance policy deployment failed."
        Write-Warn "Continuing to macOS policy deployment."
    }
}

if (-not $SkipMacOS) {
    Write-Section "macOS compliance policy"

    try {
        $MacOSPolicyBody = New-MacOSCompliancePolicyBody
        Assert-ScheduledActionsShape -PolicyBody $MacOSPolicyBody
        $MacOSPolicyId = New-OrUpdate-CompliancePolicy -PolicyBody $MacOSPolicyBody

        if ($MacOSPolicyId) {
            Set-CompliancePolicyAssignment -PolicyId $MacOSPolicyId -GroupId $TargetGroupId
        }
    }
    catch {
        Write-Fail "macOS compliance policy deployment failed."
    }
}

Write-Section "Deployment summary"
Write-Host "Windows Policy ID: $WindowsPolicyId"
Write-Host "macOS Policy ID:   $MacOSPolicyId"

Write-Host ""
Write-Success "Compliance policy deployment complete."

Write-Host ""
Write-Info "Suggested run:"
Write-Host ".\Deploy-Wave2-CompliancePolicies-v3.7.ps1 -TenantId `"<tenant-id>`" -PilotGroupId `"$TargetGroupId`" -DisableDefenderRiskCheck -ShowJson"
